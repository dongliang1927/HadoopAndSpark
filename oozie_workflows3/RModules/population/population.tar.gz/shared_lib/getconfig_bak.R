getconfig <- function(Cur_Path){
  json_path <- paste(Cur_Path,"../../config.json",sep = "/")
  if(!file.exists(json_path)){
    json_data <- list()
  }else{
    json_data <- fromJSON(paste(readLines(json_path),collapse =""))
  }
  json_path <- paste(Cur_Path,"../config.json",sep = "/")
  if(file.exists(json_path)){
    tem <-  fromJSON(paste(readLines(json_path),collapse =""))
    for(loop in names(tem)){
      if(loop %in% names(json_data)){
        index <- which(names(json_data)==loop)
        index_interal <- which(names(tem)==loop)
        json_data[[index]] <- tem[[index_interal]]
      }else{
        index_interal <- which(names(tem)==loop)
        json_data$loop <- tem[[index_interal]]
        names(json_data)[length(json_data)] <- loop
      }
    }
  }
  json_path <- paste(Cur_Path,"config.json",sep = "/")
  if(file.exists(json_path)){
    tem <-  fromJSON(paste(readLines(json_path),collapse =""))
    for(loop in names(tem)){
      if(loop %in% names(json_data)){
        index <- which(names(json_data)==loop)
        index_interal <- which(names(tem)==loop)
        json_data[[index]] <- tem[[index_interal]]
      }else{
        index_interal <- which(names(tem)==loop)
        json_data$loop <- tem[[index_interal]]
        names(json_data)[length(json_data)] <- loop
      }
    }
  }
  if(length(json_data)>0){
    return(json_data)
  }else{
    print("The config.json file(s) not exist(s).")
  }
}