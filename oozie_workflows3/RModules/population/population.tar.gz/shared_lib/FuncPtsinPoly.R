FuncPtsinPoly <- function(points_data,lnglat=c('lng','lat'),des_polygon){
  #-- packages -------
  library(foreach)
  library(doParallel)
  
  if(!( sum(c('lng','lat') %in% names(points_data))==2 | class(points_data)=="data.frame") ){
    stop("inpute_data-points_data must be a data.frame and with cols named 'lng','lat',which indicate the lngtitude an latitude")
  }
  if(class(des_polygon)[1] != "SpatialPolygonsDataFrame"){
    stop("des_polygon must be a SpatialPolygonsDataFrame")
  }
  
  #-- make a data
  town_id  <- na.omit(data.frame(town_id=des_polygon$ID[!is.na(des_polygon$ID)],stringsAsFactors = F) )
  
  #----- parallel -----#
  cores <- detectCores(logical = T)
  cl <- makeCluster(cores)
  registerDoParallel(cl, cores)
  ptm <- proc.time()
  #----- parallel -----#
  
  points_data <- ddply(town_id, .(town_id), .parallel = T, .paropts = list(.packages = c("rgeos","sp")), 
                                         .fun = function(x,points_data,des_polygon){
                                           sub_polygon <- gUnaryUnion(des_polygon[des_polygon$ID %in% x,])
                                           ov <- sp::over(SpatialPoints(cbind(points_data$lng,points_data$lat), proj4string = CRS(proj4string(sub_polygon))), gUnaryUnion(sub_polygon))
                                           if(sum(!is.na(ov))>0){
                                             data <- points_data[!is.na(ov),]
                                             data$orgid <- rep(x$townid,nrow(data))
                                           }else{
                                             data <- data.frame()
                                           }
                                           return(data)
                                         },points_data=points_data,des_polygon=des_polygon)
  
  #----- parallel -----#
  proc.time() - ptm
  stopImplicitCluster()
  stopCluster(cl)
  #----- parallel -----#
  
  #-- rlt ----------------
  return(plyr::rename(points_data, c('town_id'='orgid')))
  
}
