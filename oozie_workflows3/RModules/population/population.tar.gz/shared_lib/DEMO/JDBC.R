 
argv <- commandArgs(TRUE)
Cur_Path = as.character(argv[1])
# Cur_Path = "/data/home/wangchangsheng/sadan/trunk/backend-schedule-modules/src/main/RModules/shared_lib/DEMO"

# ------------------------------------------
# > NOTICE <  json_path <- paste(Cur_Path,"../../shared_lib/getconfig.R",sep = "/")
# ------------------------------------------
json_path <- paste(Cur_Path,"../getconfig.R",sep = "/")
source(json_path)
json_data <- getconfig(Cur_Path)

# json_path <- paste0(Cur_path,'/config.json')
# json_data <- fromJSON(paste(readLines(json_path), collapse = ""))

sql_driver_path = json_data[["sql_driver_path"]]
hive_driver_path = json_data[["hive_driver_path"]]

mysql_url = json_data[["mysql_url"]]
oracle_url=json_data[["oracle_url"]]
sqlserver_url = json_data[["sqlserver_url"]]
hive_url = json_data[["hive_url"]]

#
# **************************** HIVE ************************************
cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url,user="hjtao", password="")

call_event <- RJDBC::dbGetQuery(hiveconnection,paste("select EVENTCODE as eventcode,TYPEEVENTNAME as typename from ",in_call_event,sep = ""))#" limit 100000",

# ****************************MYSQL************************************
cp = c(list.files(sql_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
jdbcDriver <-RJDBC::JDBC(driverClass="com.mysql.jdbc.Driver",classPath=cp)
conn <- RJDBC::dbConnect(jdbcDriver, mysql_url,"public", "biontadm2016")
call_event <- RJDBC::dbGetQuery(conn,paste("select * from call_event limit 10"))#" limit 100000",

# ****************************ORACLE************************************
cp = c(list.files(sql_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
jdbcDriver <- RJDBC::JDBC(driverClass ="oracle.jdbc.driver.OracleDriver", classPath =cp) 
conn <- RJDBC::dbConnect(jdbcDriver,oracle_url,"wangchangsheng","123456")
dispute_trace <- RJDBC::dbGetQuery(conn,paste("select * from dispute_trace where rownum <= 10"))#" limit 100000",

# ****************************SQLSERVER************************************
cp = c(list.files(sql_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
jdbcDriver <- RJDBC::JDBC(driverClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver", classPath =cp) 
conn <- RJDBC::dbConnect(jdbcDriver,sqlserver_url,"sa","bionta")
Components <- RJDBC::dbGetQuery(conn,paste("select * from Components"))#" limit 100000",

