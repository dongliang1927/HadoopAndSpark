FuncCoordConv <- function(var_conv1, lnglat=c('lng','lat'), from=1, to=5, AK="4SoaSvbIZ0HkLCrpxf32VHj7gvnxadQm"){
  if(!(from %in% c(1,2,3,4,5,6,7,8) | to %in% c(5,6) | class(var_conv1) == "data.frame")){
    stop("from: 1:GPS设备获取的角度坐标; 2：GPS获取的米制坐标、sogou地图所用坐标; 
                3：google地图、soso地图、aliyun地图、mapabc地图和amap地图所用坐标;
                4：3中列表地图坐标对应的米制坐标; 5：百度地图采用的经纬度坐标; 
                6：百度地图采用的米制坐标; 7：mapbar地图坐标; 8：51地图坐标
        to : 5：bd09ll(百度经纬度坐标); 6：bd09mc(百度米制经纬度坐标);")
  }
  library(RCurl)
  library(rjson)
  library(foreach)
  library(doParallel)
  library(plyr)
  library(dplyr)
  library(tidyr)
  
  #--- para ---#
  var_conv1 <- var_conv1 %>% unite_("xy",c(lnglat[1],lnglat[2]),sep=',') %>% as.data.frame
  var_conv1$group <- rep(1:ceiling(nrow(var_conv1)/100),each=100)[1:nrow(var_conv1)] # 百度api每次请求100条
  var_conv1$rownames <- 1:dim(var_conv1)[1] # 使用rownames对齐原始数据和api请求返回的数据
  xy <- 'xy'
  #--- para ---#
  
  #----- parallel -----#
  cores <- detectCores(logical = T)
  cl <- makeCluster(cores)
  registerDoParallel(cl, cores)
  #----- parallel -----#
  
  #--- application to all the data ---#
  ptm <- proc.time()
  
  baidu_coord <- ddply(var_conv1, .(group), .parallel = T, .paropts = list(.packages = c("RCurl","rjson")), .fun = function(x,xy,from,to,AK){
    if( nrow(x)<1 | ncol(x)<1 )stop("x must have more than one rows/cols")
    if(class(x)!="data.frame")stop("x must be a data.frame")
    if(!(xy %in% names(x)))stop("xy must a colname of x and is shaped as: 'lon,lat'")
    if(!is.numeric(from) | !is.numeric(to) | from > 8 | to < 5 | to > 6)stop("from: 1:GPS设备获取的角度坐标; 2：GPS获取的米制坐标、sogou地图所用坐标; 
                                                                             3：google地图、soso地图、aliyun地图、mapabc地图和amap地图所用坐标
                                                                             4：3中列表地图坐标对应的米制坐标; 5：百度地图采用的经纬度坐标; 
                                                                             6：百度地图采用的米制坐标; 7：mapbar地图坐标; 8：51地图坐标
                                                                             to:   5：bd09ll(百度经纬度坐标); 6：bd09mc(百度米制经纬度坐标);")
  
  strgeo <- paste(x[,xy], collapse = ";")
  
  #--- make a url ---#
  strurl <- paste0("http://api.map.baidu.com/geoconv/v1/?coords=", strgeo, "&from=", from, "&to=", to, "&output=json&ak=", AK)
  tryCatch(encodeurl <- URLencode(strurl), error=function(e){cat("ERROR : ", conditionMessage(e),"\n")})
  
  #--- convert coords ---#
  connect <- url(encodeurl) # 捕获链接对象
  temp_geo <- fromJSON(paste(readLines(connect, warn = F), collapse = ""))
  temp <- do.call("rbind", temp_geo$result)
  data <- paste(temp[,1], temp[,2], sep = ',')
  close(connect)
  
  return(data.frame(xy=data,rownames=x$rownames))
},xy=xy, from=from, to=to, AK=AK)

proc.time() - ptm

#----- parallel -----#
stopImplicitCluster()
stopCluster(cl)
#----- parallel -----#

# rlt<-plyr::join(var_conv1[, !(names(var_conv1) %in% 'group')], baidu_coord, by='rownames') %>% mutate(group=NULL,rownames=NULL) %>% 
#   separate(xy,c('lng','lat'),sep=',') %>% mutate(lng=as.numeric(lng),lat=as.numeric(lat)) %>% as.data.frame
rlt<-var_conv1[, !(names(var_conv1) %in% c('group','xy'))] %>% left_join(baidu_coord[, !(names(baidu_coord) %in% 'group')], by='rownames') %>% 
  mutate(group=NULL,rownames=NULL) %>% separate(xy,c('lng','lat'),sep=',') %>% mutate(lng=as.numeric(lng),lat=as.numeric(lat)) %>% as.data.frame
return(rlt)
}
