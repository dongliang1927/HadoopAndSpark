LanZhou_town_ID:
	该shp文件为兰州市各城镇的地理坐标数据，字段更名为：townid,townname,countyname,countyid,cityid,cityname,ID。其中，ID为维拓公司提供。
LanZhou_city_ID:
	该shp文件为兰州市各区域的地理坐标数据，字段更名为：countyname,countyid,cityid,cityname,ID。其中，ID为维拓公司提供。