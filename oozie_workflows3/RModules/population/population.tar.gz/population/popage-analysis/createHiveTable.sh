#!/bin/bash
 
hive -e "CREATE DATABASE IF NOT EXISTS $1; DROP TABLE IF EXISTS $1.$3;
CREATE  TABLE $1.$3(rownames string,orgid string,orgname string,orgpath string,parentid string,age int,no_married_male int,married_male int,no_married_female int,married_female int,date string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:age,cf:no_married_male,cf:married_male,cf:no_married_female,cf:married_female,cf:date\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$3\"); 



DROP TABLE IF EXISTS $1.$4;
CREATE  TABLE $1.$4(rownames string,orgid string,orgname string,orgpath string,parentid string,name string,averagevalue double,midianvalue double,date string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:averagevalue,cf:midianvalue,cf:date\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$4\");

DROP TABLE IF EXISTS $1.$5;
CREATE  TABLE $1.$5(rownames string,orgid string,orgname string,orgpath string,parentid string,name string,value int,date string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:value,cf:date\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$5\");

DROP TABLE IF EXISTS $1.$6;
CREATE  TABLE $1.$6(rownames string,orgid string,orgname string,orgpath string,parentid string,male_number int,female_number int,date string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:male_number,cf:female_number,cf:date\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$6\");

DROP TABLE IF EXISTS $1.$7;
CREATE  TABLE $1.$7(rownames string,orgid string,orgname string,orgpath string,parentid string,name string,value double,date string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:value,cf:date\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$7\");



"

impala-shell -i $2 -q "INVALIDATE METADATA" 
