rm(list = ls())
graphics.off()

library(plyr)
library(dplyr)
library(timeDate)
library(RJDBC)
library(rjson)
library(rgdal)
library(doParallel)
options(scipen = 20)

argv <- commandArgs(TRUE)
Cur_Path = as.character(argv[1])
json_path <- paste(Cur_Path,"../../shared_lib/getconfig.R",sep = "/")
# json_path <- "/data/home/zhaochuanhu/development/population_v3/shared_lib/getconfig.R"
# Cur_Path <- "/data/home/zhaochuanhu/development/population_v3/base_people_preprocess/popage-analysis/"
source(json_path)
json_data <- getconfig(Cur_Path)
json_name=names(json_data)

runtype = as.numeric(json_data[which(json_name == "runtype")])#runtype=1为R调用模式，否则为Java命令行调用模式
dsn_name = as.character(json_data[which(json_name == "dsn")])
uid_name = as.character(json_data[which(json_name == "uid")])
pwd_name = as.character(json_data[which(json_name == "pwd")])

# threshold = as.numeric(json_data[which(json_name == "threshold")])
# text_diff = as.character(json_data[which(json_name == "text_diff")])
# text_mean = as.character(json_data[which(json_name == "text_mean")])
# text_mid = as.character(json_data[which(json_name == "text_mid")])
# text_var = as.character(json_data[which(json_name == "text_var")])
maxage = as.numeric(json_data[which(json_name == "maxage")])

Coding_Building = as.numeric(json_data[which(json_name=="Coding_Buid")])
Coding_Grid = as.numeric(json_data[which(json_name=="Coding_Grid")])

tablename_r_people = as.character(json_data[which(json_name=="in_table_r_people")])

# tablename_rlt_people_preprocess = as.character(json_data[which(json_name=="in_table_rlt_people_preprocess")])
tablename_baseorg = as.character(json_data[which(json_name=="in_table_baseorg")])
# tablename_levelset = as.character(json_data[which(json_name=="in_table_levelset")])

out_table_fig1 = as.character(json_data[which(json_name=="out_table_fig1")])
out_table_fig2 = as.character(json_data[which(json_name=="out_table_fig2")])
out_table_fig3 = as.character(json_data[which(json_name=="out_table_fig3")])
out_table_fig4 = as.character(json_data[which(json_name=="out_table_fig4")])
out_table_fig5 =  as.character(json_data[which(json_name=="out_table_fig5")])
# READ HIVE ************************************************************
impalaurl <- as.character(json_data[["impalaurl"]])
hive_driver_path <- as.character(json_data[["hivedriver"]])
hive_name <- as.character(json_data[["hiveuser"]])
hive_password <- as.character(json_data[["hivepassword"]])
hive_url_in <- as.character(json_data[["hiveurlin"]])
hive_url_out <- as.character(json_data[["hiveurlout"]])
hivedatabase <- unlist(strsplit(hive_url_out,'/'))
hivedatabase <- hivedatabase[length(hivedatabase)]
# READ HIVE ************************************************************

# READ HIVE ****************************************************************
cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url_in,user=hive_name, password=hive_password)

r_people <- RJDBC::dbGetQuery(hiveconnection,paste("select birthday ,gender , marryname as marryname, orgid as orgid , createtime as date from ", tablename_r_people, sep = ""))
base_org <- RJDBC::dbGetQuery(hiveconnection,paste("select * from ", tablename_baseorg, sep = ""))

RJDBC::dbDisconnect(hiveconnection)
# READ HIVE ****************************************************************

#-------------------------------------------------------ODBC------------------------------------------
# pep <- odbcConnect(dsn_name, uid=uid_name, pwd=pwd_name,believeNRows=FALSE,DBMSencoding="utf8");
# #P_S_ID<-sqlFetch(pep,tablename)# 查看表的内容，存到数据框里
# r_people <- sqlQuery(pep,paste("select id,marryname from ",tablename_r_people))
# rlt_people_preprocess <- sqlQuery(pep,paste("select * from",tablename_rlt_people_preprocess))
# base_org <- sqlQuery(pep,paste("select * from",tablename_baseorg))
# levelset <- sqlQuery(pep,paste("select id,coding from",tablename_levelset))
# close(pep)  # 关闭连接
#-----------------------------------------------------------------------------------------------------
r_people$birthday <- r_people$birthday %>% substring(1,4) %>% as.numeric()
r_people$age <- (timeDate() %>% substring(1,4) %>% as.numeric()) - r_people$birthday
base_org <- base_org %>% rename("orgid" = "base_org.id", "orgpath" = "base_org.path", "parentid"= "base_org.parentid")
r_people <- r_people %>% join(base_org[,c("orgid", "orgpath")], by = "orgid", type = "left")
r_people$date <- r_people$date %>% substring(1,7)

P_S <-data.frame(age = 1:maxage)
P_S <- join(P_S, r_people, by = "age", type = "left")
base_org <- base_org[-c(1:2,4:7),]
P_S$marryname <- sub("丧偶", "未婚", P_S$marryname)
P_S$marryname <- sub("离婚", "未婚", P_S$marryname)
P_S$marryname <-sub("再婚", "已婚", P_S$marryname)
P_S$marryname <- sub("初婚", "已婚", P_S$marryname)
P_S$marryname <- sub("复婚", "已婚", P_S$marryname)
P_S$age <- as.numeric(P_S$age)

func <- function(n, base_org, P_S){
  
  library(plyr)
  library(dplyr)
  Base_Index = grep(base_org$orgpath[n],base_org$orgpath,value=F)
  Base_ID  = base_org[Base_Index,]
  Poly_Index = which(P_S$orgpath %in% Base_ID$orgpath)
  if(length(Poly_Index) > 0){
    Cur_member <- P_S[Poly_Index,]
    Cur_member$age <- as.numeric(Cur_member$age)
  }else{
    Cur_member <- data.frame(age = 0 , gender = 0, marryname = 0, orgid = 0, orgpath = 0)
    Cur_member <- Cur_member[-1,]
  }
  #-----------------------------------------------------------------------------------------------------
  # Cur_member <- P_S[grep(base_org$base_org.path[n], P_S$orgpath), ] #这条语句和上面的一段代码功能是相同的，但是执行效率太低，大约是上面的七倍
  #----------------------------------------------------------------------------------------------------- 
  #aggregate
  if(nrow(Cur_member) > 0){
    
    Cm <- Cur_member %>% plyr::count(c("age", "gender", "marryname"))  %>% data.frame()
    if(nrow(Cm) > 0){
      #Cm <- na.omit(Cm)
      ts <- Cm
      
      
      
      ts1 <- (subset(ts, gender == "男" & marryname == "未婚"))[ ,c(-2, -3)]
      tmp <- data.frame(age = 0, no_married_male = 0)
      names(ts1) <- c("age",  "no_married_male")
      tmp <- rbind(tmp,ts1) 
      
      ts1 <- (subset(ts, gender == "男" & marryname == "已婚"))[ ,c(-2, -3)]
      names(ts1) <- c("age",  "married_male")
      tmp <- plyr::join(tmp, ts1, by = "age", type = "left")
      
      ts1 <- (subset(ts, gender == "女" & marryname == "未婚"))[ ,c(-2, -3)]
      names(ts1) <- c("age", "no_married_female")
      tmp <- plyr::join(tmp, ts1, by = "age", type = "left")
      
      ts1 <- (subset(ts, gender == "女" & marryname == "已婚"))[ ,c(-2, -3)]
      names(ts1) <- c("age",  "married_female")
      tmp <- plyr::join(tmp, ts1, by = "age", type = "left")
      tmp$orgid <- base_org$orgid[n]
      tmp$parentid <- base_org$parentid[n]
      tmp$orgpath <- base_org$orgpath[n]
      tmp$orgname <- base_org$base_org.orgname[n]
      tmp$date <- Cur_member$date[1]
    }else{
      tmp <- data.frame(age = 0, no_married_male = 0, married_male = 0,no_married_female,married_female,orgid = base_org$orgid[n], 
                        parentid = base_org$parentid[n],orgpath = base_org$orgpath[n],orgname = base_org$base_org.orgname[n],date = 0)
    }
    
    Cm <- Cur_member %>% plyr::count(c("age"))  %>% data.frame()
    if(nrow(Cm) > 0){
      tmp1 <- Cm
      
      if(nrow(tmp1) > 0){
        names(tmp1) <- c("name", "value")
        tmp1$orgid <- base_org$orgid[n]
        tmp1$parentid <- base_org$parentid[n]
        tmp1$orgpath <-base_org$orgpath[n]
        tmp1$orgname <- base_org$base_org.orgname[n]
        tmp1$date <- Cur_member$date[1]
      }
    }else{
      tmp1 <- data.frame(name = NA, value = 0, orgid = base_org$orgid[n], 
                         parentid = base_org$parentid[n],orgpath = base_org$orgpath[n], orgname = base_org$base_org.orgname[n],date = 0)
    }
    
    Cm <- Cur_member %>% plyr::count(c("age", "gender"))  %>% data.frame()
    if(nrow(Cm) > 0){
      ts <- Cm
      if(length(which(ts$gender == "男")) > 0 & length(which(ts$gender == "女")) > 0){
        tmp2 <- data.frame(male_number = sum(ts[which(ts$gender == "男"),]$freq), female_number = sum(ts[which(ts$gender == "女"), ]$freq))
        # tmp2 <- data.frame(male_number = 0, female_number = 0)
        # tmp2$male_number
        tmp2$orgid <- base_org$orgid[n]
        tmp2$parentid <- base_org$parentid[n]
        tmp2$orgpath <- base_org$orgpath[n]
        tmp2$orgname <- base_org$base_org.orgname[n]
        tmp2$date <- Cur_member$date[1]
      }else if(length(which(ts$gender == "男")) > 0){
        
        tmp2 <- data.frame(male_number = ts[which(ts$gender == "男"), 2], female_number = 0,orgid = base_org$orgid[n],
                           parentid = base_org$parentid[n],orgpath = base_org$orgpath[n],orgname = base_org$base_org.orgname[n],date = Cur_member$date[1])
        
      }else{
        
        tmp2 <- data.frame(male_number = 0, female_number = ts[which(ts$gender == "女"), 2],orgid = base_org$orgid[n],
                           parentid = base_org$parentid[n],orgpath = base_org$orgpath[n],orgname = base_org$base_org.orgname[n],date = Cur_member$date[1])
        
      }
      
      
      ts <- Cm
      
      if(length(which(ts$gender == "男")) > 0 & length(which(ts$gender == "女")) > 0){
        age_dat <- data.frame(age = 1:100)
        age_dat$gender <- "男"
        male <- age_dat %>% join(ts[which(ts$gender == "男"),], by = c("age","gender"),type = "left")
        if(sum(is.na(male$freq)) > 0){
          male[is.na(male$freq),]$freq <- 0
        }
        
        age_dat$gender <- "女"
        female <- age_dat %>% join(ts[which(ts$gender == "女"), ], by = c("age","gender"),type = "left")
        if(sum(is.na(female$freq)) > 0){
          female[is.na(female$freq),]$freq <- 0
        }
        
        tmp3 <- data.frame(name = female$age, value = male$freq/female$freq)
        tmp3$orgid <- base_org$orgid[n]
        tmp3$parentid <- base_org$parentid[n]
        tmp3$orgpath <- base_org$orgpath[n]
        tmp3$orgname <- base_org$base_org.orgname[n]
        tmp3$date <- Cur_member$date[1]
      }else if(length(which(ts$gender == "男")) > 0){
        
        male <- ts[which(ts$gender == "男"),]
        female <- data.frame(age = male$age, gender = "女" , freq = 0)
        tmp3 <- data.frame(name = female$age, value = male$freq/female$freq)
        tmp3$orgid <- base_org$orgid[n]
        tmp3$parentid <- base_org$parentid[n]
        tmp3$orgpath <- base_org$orgpath[n]
        tmp3$orgname <- base_org$base_org.orgname[n]
        tmp3$date <- Cur_member$date[1]
        
      }else{
        
        female <- ts[which(ts$gender == "女"), ]
        male <- data.frame(age = female$age, gender = "男", freq = 0)
        tmp3 <- data.frame(name = female$age, value = male$freq/female$freq)
        tmp3$orgid <- base_org$orgid[n]
        tmp3$parentid <- base_org$parentid[n]
        tmp3$orgpath <- base_org$orgpath[n]
        tmp3$orgname <- base_org$base_org.orgname[n]
        tmp3$date <- Cur_member$date[1]
      }
    }else{
      
      tmp2 <-data.frame(malenumber = 0, femalenumber = 0, orgid = base_org$orgid[n], 
                        parentid = base_org$parentid[n],orgpath = base_org$orgpath[n],orgname = base_org$base_org.orgname[n],date = 0)
      tmp3 <- data.frame(name = NA, value = NA, orgid = base_org$orgid[n], 
                         parentid = base_org$parentid[n],orgpath = base_org$orgpath[n],orgname = base_org$base_org.orgname[n],date = 0)
      
    }
    
    if(length(which(Cur_member$gender == "男")) > 0 & length(which(Cur_member$gender == "女")) > 0){
      ts <- summary(Cur_member[which(Cur_member$gender == "男"),]$age)
      male_mean <- as.numeric(ts[4])
      male_median <- as.numeric(ts[3])
      
      ts <- summary(Cur_member[which(Cur_member$gender == "女"),]$age)
      female_mean <- as.numeric(ts[4])
      female_median <- as.numeric(ts[3])
      
      ts <- summary(Cur_member$age)
      all_mean <- as.numeric(ts[4])
      all_median <- as.numeric(ts[3])
      
      diff_num <- data.frame(averagevalue = all_mean, midianvalue = all_median,  name = "整体")
      # tmp4 <- diff_num
      # diff_num <- data.frame(x_age = all_median, y_value = 0, text = text_mid, born_year = Today_year-all_median, type = "整体")
      # tmp4 <- rbind(tmp4, diff_num)
      
      diff_num <- data.frame(averagevalue = male_mean, midianvalue = male_median,  name = "男性") %>% rbind(diff_num)
      # tmp4 <- rbind(tmp4, diff_num)
      # diff_num <- data.frame(x_age = male_median, y_value = 0, text = text_mid, born_year = Today_year-male_median, type = "男性")
      # tmp4 <- rbind(tmp4, diff_num)
      
      diff_num <- data.frame(averagevalue = female_mean, midianvalue = female_median, name = "女性") %>% rbind(diff_num)
      # tmp4 <- rbind(tmp4, diff_num)
      # diff_num <- data.frame(x_age = female_median, y_value = 0, text = text_mid, born_year = Today_year-female_median, type = "女性")
      # tmp4 <- rbind(tmp4, diff_num)
      tmp4 <- diff_num
      tmp4$orgid <- base_org$orgid[n]
      tmp4$parentid <- base_org$parentid[n]
      tmp4$orgpath <- base_org$orgpath[n]
      tmp4$orgname <- base_org$base_org.orgname[n]
      tmp4$date <- Cur_member$date[1]
      
    }else if(length(which(Cur_member$gender == "男")) > 0){
      
      ts <- summary(Cur_member[which(Cur_member$gender == "男"),]$age)
      male_mean <- as.numeric(ts[4])
      male_median <- as.numeric(ts[3])
      
      ts <- summary(Cur_member$age)
      all_mean <- as.numeric(ts[4])
      all_median <- as.numeric(ts[3]) 
      
      diff_num <- data.frame(averagevalue = all_mean, midianvalue = all_median,  name = "整体")

      # diff_num <- data.frame(x_age = all_mean, y_value = 0, text = text_mean, born_year = Today_year-all_mean, type = "all")
      # tmp4 <- diff_num
      # diff_num <- data.frame(x_age = all_median, y_value = 0, text = text_mid, born_year = Today_year-all_median, type = "all")
      # tmp4 <- rbind(tmp4, diff_num)
      diff_num <- data.frame(averagevalue = male_mean, midianvalue = male_median,  name = "男性")%>% rbind(diff_num)
      
      # diff_num <- data.frame(x_age = male_mean, y_value = 0, text = text_mean, born_year = Today_year-male_mean, type = "male")
      # tmp4 <- rbind(tmp4, diff_num)
      # diff_num <- data.frame(x_age = male_median, y_value = 0, text = text_mid, born_year = Today_year-male_median, type = "male")
      # tmp4 <- rbind(tmp4, diff_num)
      tmp4 <- diff_num
      tmp4$orgid <- base_org$orgid[n]
      tmp3$parentid <- base_org$parentid[n]
      tmp4$orgpath <- base_org$orgpath[n]
      tmp4$orgname <- base_org$base_org.orgname[n]
      tmp4$date <- Cur_member$date[1]
      
    }else{
      
      ts <- summary(Cur_member[which(Cur_member$gender == "男"),]$age)
      male_mean <- as.numeric(ts[4])
      male_median <- as.numeric(ts[3])
      
      ts <- summary(Cur_member[which(Cur_member$gender == "女"),]$age)
      female_mean <- as.numeric(ts[4])
      female_median <- as.numeric(ts[3])
      
      ts <- summary(Cur_member$age)
      all_mean <- as.numeric(ts[4])
      all_median <- as.numeric(ts[3])
      
      diff_num <- data.frame(averagevalue = all_mean, midianvalue = all_median,  name = "整体")
      
      
      # diff_num <- data.frame(x_age = all_mean, y_value = 0, text = text_mean, born_year = Today_year-all_mean, type = "all")
      # tmp4 <- diff_num
      # diff_num <- data.frame(x_age = all_median, y_value = 0, text = text_mid, born_year = Today_year-all_median, type = "all")
      # tmp4 <- rbind(tmp4, diff_num)
      
      diff_num <- data.frame(averagevalue = female_mean, midianvalue = female_median,  name = "女性")%>% rbind(diff_num)
      
      # diff_num <- data.frame(x_age = female_median, y_value = 0, text = text_mean, born_year = Today_year-female_mean, type = "female")
      # tmp4 <- rbind(tmp4, diff_num)
      # diff_num <- data.frame(x_age = female_median, y_value = 0, text = text_mid, born_year = Today_year-female_median, type = "female")
      # tmp4 <- rbind(tmp4, diff_num)
      tmp4 <- diff_num
      tmp4$orgid <- base_org$orgid[n]
      tmp3$parentid <- base_org$parentid[n]
      tmp4$orgpath <- base_org$orgpath[n]
      tmp4$orgname <- base_org$base_org.orgname[n]
      tmp4$date <- Cur_member$date[1]
      
    }
    
    return(list(tmp, tmp1, tmp2, tmp3, tmp4))
    
  }
}

system.time({
  # Today_year = as.numeric(substr(Sys.Date(),start = 1,stop = 4)) #提取系统当前年份
  n = 1:nrow(base_org)
#--------------------------------------------------------------------------
  cores <- detectCores(logical = FALSE)
  cl <- makeCluster(cores)
#--------------------------------------------------------------------------
  results <- parLapply(cl, n, func, base_org, P_S)
  fig1 <- ldply(results, function(y) rbind(y[[1]]))
  fig3 <- ldply(results, function(y) rbind(y[[2]]))
  fig4 <- ldply(results, function(y) rbind(y[[3]]))
  fig5 <- ldply(results, function(y) rbind(y[[4]]))
  fig2 <- ldply(results, function(y) rbind(y[[5]]))
  fig1 <- fig1[which(fig1$age != 0),]
  fig5[is.infinite(fig5$value),]$value <- 0
  
  # fig1 <- fig1 %>% rename("no_married_male" = "male_no_married","no_married_female" = "female_no_married")
  # fig2 <- fig2 %>% rename("name" = "age")
  # fig4 <- fig4 %>% rename("name" = "age", "value" = "ratio")
  stopCluster(cl)
})

############# SAVE-HIVE ##############
cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names = T, recursive = T), recursive = T)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver", classPath = cp)
hiveconnection = RJDBC::dbConnect(drv, hive_url_out, user = hive_name, password = hive_password)
inserHiveFunctionV2(hiveconnection, hivedatabase, impalaurl, step = 10000,
                    fig1, out_table_fig1,
                    fig2, out_table_fig2,
                    fig3, out_table_fig3,
                    fig4, out_table_fig4,
                    fig5, out_table_fig5)
RJDBC::dbDisconnect(hiveconnection)
#######################################
