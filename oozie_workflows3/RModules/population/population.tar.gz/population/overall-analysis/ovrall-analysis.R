rm(list = ls())
graphics.off()

library(plyr)
library(dplyr)
library(RJDBC)
library(rjson)
library(timeDate)
library(rgdal)
library(doParallel)
options(scipen = 20)

 argv <- commandArgs(TRUE)
 Cur_Path = as.character(argv[1])
 json_path <- paste(Cur_Path,"../../shared_lib/getconfig.R",sep = "/")
#json_path <- "/data/home/zhaochuanhu/development/population_v3/shared_lib/getconfig.R"
#Cur_Path <- "/data/home/zhaochuanhu/development/population_v3/base_people_preprocess/overall-analysis/"
source(json_path)
json_data <- getconfig(Cur_Path)
json_name=names(json_data)

runtype = as.numeric(json_data[which(json_name == "runtype")])#runtype=1为R调用模式，否则为Java命令行调用模式
dsn_name = as.character(json_data[which(json_name == "dsn")])
uid_name = as.character(json_data[which(json_name == "uid")])
pwd_name = as.character(json_data[which(json_name == "pwd")])

Travers_low <- as.numeric(json_data[which(json_name == "Travers_low")])
Travers_high <- as.numeric(json_data[which(json_name == "Travers_high")])

childhood_low <- as.numeric(json_data[which(json_name == "childhood_low")])
childhood_high <- as.numeric(json_data[which(json_name == "childhood_high")])
childhood_interval <- paste(childhood_low,childhood_high, sep = "~")
childhood_name  <-  paste(as.character(json_data[which(json_name == "childhood_name")]), "(",childhood_interval, ")", sep = "")

early_youth_low <- as.numeric(json_data[which(json_name == "early_youth_low")])
early_youth_high <- as.numeric(json_data[which(json_name == "early_youth_high")])
early_youth_interval <- paste(early_youth_low,early_youth_high, sep = "~")
early_youth_name  <-  paste(as.character(json_data[which(json_name == "early_youth_name")]), "(",early_youth_interval, ")", sep = "")

youth_low <- as.numeric(json_data[which(json_name == "youth_low")])
youth_high <- as.numeric(json_data[which(json_name == "youth_high")])
youth_interval <- paste(youth_low,youth_high, sep = "~")
youth_name  <-  paste(as.character(json_data[which(json_name == "youth_name")]), "(",youth_interval, ")", sep = "")

middle_age_low <- as.numeric(json_data[which(json_name == "middle_age_low")])
middle_age_high <- as.numeric(json_data[which(json_name == "middle_age_high")])
middle_age_interval <- paste(middle_age_low,middle_age_high, sep = "~")
middle_age_name  <-  paste(as.character(json_data[which(json_name == "middle_age_name")]),"(", middle_age_interval, ")", sep = "")

older_Age_low <-  as.numeric(json_data[which(json_name == "older_Age_low")])
older_Age_high <-  as.numeric(json_data[which(json_name == "older_Age_high")])
older_interval <- paste(older_Age_low,"以上", sep = "")
older_name  <-  paste(as.character(json_data[which(json_name == "older_name")]),"(", older_interval, ")", sep = "")

UN_Juvenils_low <-  as.numeric(json_data[which(json_name == "UN_Juvenils_low")])
UN_Juvenils_high <-  as.numeric(json_data[which(json_name == "UN_Juvenils_high")])
UN_Juvenils_interval <- paste(UN_Juvenils_low,UN_Juvenils_high, sep = "~")
UN_Juvenils_name <-   paste(as.character(json_data[which(json_name == "UN_Juvenils_name")]), "(",UN_Juvenils_interval, ")", sep = "")

UN_youth_low <-  as.numeric(json_data[which(json_name == "UN_youth_low")])
UN_youth_high <-  as.numeric(json_data[which(json_name == "UN_youth_high")])
UN_youth_interval <- paste(UN_youth_high,UN_youth_high, sep = "~")
UN_youth_name <-  paste(as.character(json_data[which(json_name == "UN_youth_name")]), "(",UN_youth_interval, ")", sep = "")

UN_middle_age_low <-  as.numeric(json_data[which(json_name == "UN_middle_age_low")])
UN_middle_age_high <-  as.numeric(json_data[which(json_name == "UN_middle_age_high")])
UN_middle_interval <- paste(UN_middle_age_low,UN_middle_age_high, sep = "~")
UN_middle_age_name <-  paste(as.character(json_data[which(json_name == "UN_middle_age_name")]), "(",UN_middle_interval, ")", sep = "")

UN_older_Age_low <-  as.numeric(json_data[which(json_name == "UN_older_Age_low")])
UN_older_Age_high <-  as.numeric(json_data[which(json_name == "UN_older_Age_high")])
UN_older_interval <- paste(UN_older_Age_low,UN_older_Age_high, sep = "~")
UN_older_Age_name <-   paste(as.character(json_data[which(json_name == "UN_older_Age_name")]),"(", UN_older_interval, ")", sep = "")

UN_Longevous_low <-  as.numeric(json_data[which(json_name == "UN_Longevous_low")])
UN_Longevous_high <-  as.numeric(json_data[which(json_name == "UN_Longevous_high")])
UN_Longevous_interval <- paste(UN_Longevous_low,UN_Longevous_high, sep = "~")
UN_Longevous_name <-  paste(as.character(json_data[which(json_name == "UN_Longevous_name")]),"(", UN_Longevous_interval, ")", sep = "")

age_interval_length <- as.numeric(json_data[which(json_name == "age_interval_length")])
age_interval_lowest <- as.numeric(json_data[which(json_name == "age_interval_lowest")])
age_interval_highest <- as.numeric(json_data[which(json_name == "age_interval_highest")])

age_interval <- data.frame(interval = rep(NA, (age_interval_highest - age_interval_lowest)/age_interval_length + 1), age_low = NA, age_high = NA)
for (i in 1:((age_interval_highest - age_interval_lowest)/age_interval_length +1)) {
  if(i != (age_interval_highest - age_interval_lowest)/age_interval_length + 1){
    age_interval$interval[i] <-  paste(age_interval_lowest + age_interval_length*(i - 1), age_interval_lowest + age_interval_length*i,sep = "~")
    age_interval$age_low[i] <- age_interval_lowest + age_interval_length*(i - 1)
    age_interval$age_high[i] <- age_interval_lowest + age_interval_length*i
  }else{
    age_interval$interval[i] <-  paste(age_interval_lowest + age_interval_length*(i - 1), "以上",sep = "")
    age_interval$age_low[i] <- age_interval_lowest + age_interval_length*(i - 1)
    age_interval$age_high[i] <- Inf
  }
}


Age_Divide <- data.frame(age_low = c(childhood_low,early_youth_low,youth_low,middle_age_low,older_Age_low), 
                         age_high = c(childhood_high,early_youth_high,youth_high,middle_age_high,older_Age_low), 
                         age_name = c(childhood_name,early_youth_name,youth_name,middle_age_name,older_name))
UN_Age_Divide <- data.frame(name = c(UN_Juvenils_name,UN_youth_name,UN_middle_age_name,UN_older_Age_name,UN_Longevous_name),
                            age_low = c(UN_Juvenils_low,UN_youth_low,UN_middle_age_low,UN_older_Age_low,UN_Longevous_low),
                            age_high = c(UN_Juvenils_high,UN_youth_high,UN_middle_age_high,UN_older_Age_high,UN_Longevous_high))

text_diff = as.character(json_data[which(json_name == "text_diff")])
text_mean = as.character(json_data[which(json_name == "text_mean")])
text_mid = as.character(json_data[which(json_name == "text_mid")])
text_var = as.character(json_data[which(json_name == "text_var")])
maxage = as.numeric(json_data[which(json_name == "maxage")])

Coding_Building = as.numeric(json_data[which(json_name=="Coding_Buid")])
Coding_Grid = as.numeric(json_data[which(json_name=="Coding_Grid")])

tablename_r_people = as.character(json_data[which(json_name=="in_table_r_people")])


tablename_baseorg = as.character(json_data[which(json_name=="in_table_baseorg")])
base_chinacoordinate = as.character(json_data[which(json_name=="in_table_coordinate")])

out_table_fig1 = as.character(json_data[which(json_name=="out_table_fig1")])
out_table_fig2 = as.character(json_data[which(json_name=="out_table_fig2")])
out_table_fig3 = as.character(json_data[which(json_name=="out_table_fig3")])
out_table_fig4 = as.character(json_data[which(json_name=="out_table_fig4")])
out_table_fig5 =  as.character(json_data[which(json_name=="out_table_fig5")])
out_table_fig6 = as.character(json_data[which(json_name=="out_table_fig6")])
out_table_fig7 =  as.character(json_data[which(json_name=="out_table_fig7")])

# READ HIVE ************************************************************
impalaurl <- as.character(json_data[["impalaurl"]])
hive_driver_path <- as.character(json_data[["hivedriver"]])
hive_name <- as.character(json_data[["hiveuser"]])
hive_password <- as.character(json_data[["hivepassword"]])
hive_url_in <- as.character(json_data[["hiveurlin"]])
hive_url_out <- as.character(json_data[["hiveurlout"]])
hivedatabase <- unlist(strsplit(hive_url_out,'/'))
hivedatabase <- hivedatabase[length(hivedatabase)]
# READ HIVE ************************************************************

# READ HIVE ****************************************************************
cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url_in,user=hive_name, password=hive_password)

r_people <- RJDBC::dbGetQuery(hiveconnection,paste("select id as people_id, cardno,orgid as orgid, birthday as birthday, gender, edulevelname,createtime as date, df8 as name  from ", tablename_r_people, sep = ""))
base_org <- RJDBC::dbGetQuery(hiveconnection,paste("select id as orgid, parentid,path as orgpath, orgname, codeno from ", tablename_baseorg, sep = ""))
base_chinacoordinate <- RJDBC::dbGetQuery(hiveconnection,paste("select city , coding_city, county, coding_cnt from ", base_chinacoordinate, sep = ""))

RJDBC::dbDisconnect(hiveconnection)
# load("/data/home/zhaochuanhu/development/population_v3/temp_data/base_org.RData")
# load("/data/home/zhaochuanhu/development/population_v3/temp_data/r_people.RData")
#***********************************************************************************************
educlean <- function(edulevelname){
  
  edulevelname[grep(c('小'), edulevelname)] = "小学"
  edulevelname[grep('初', edulevelname)] = "初级中学"
  edulevelname[grep('高', edulevelname)] = "普通高中"
  edulevelname[grep('技', edulevelname)] = "技校"
  edulevelname[grep('专', edulevelname)][grep('中', edulevelname[grep('专', edulevelname)])] = "中专"
  edulevelname[grep('专', edulevelname)][-grep('中', edulevelname[grep('专', edulevelname)])] = "大学专科"
  edulevelname[grep('本', edulevelname)] = "大学本科"
  edulevelname[grep('博', edulevelname)][-grep('后', edulevelname[grep('博', edulevelname)])] = "博士"
  edulevelname[grep('后', edulevelname)] = "博士后"
  edulevelname[grep('硕', edulevelname)] = "研究生"
  edulevelname[grep('研', edulevelname)] = "研究生"
  edulevelname[grep('MBA', edulevelname)] = "研究生"
  edulevelname[grep('大', edulevelname)][-grep('专', edulevelname[grep('大', edulevelname)])]  = "大学本科"
  edulevelname[grep('其', edulevelname)] = "其他"
  
  return(edulevelname)
  
}
Edu_Level <- data.frame(name = c("小学","初级中学","普通高中","技校","中专","大学专科","大学本科","博士","博士后","研究生","其他"),stringsAsFactors = F)
#**************************************************************************************************


info_population <- r_people
info_population$birthday <- info_population$birthday %>% substring(1,4) %>% as.numeric()
info_population$age <- (timeDate() %>% substring(1,4) %>% as.numeric()) - info_population$birthday
info_population$date <- info_population$date %>% substring(1,7)
info_population[grep("常住人口",info_population$name),]$name <- "常住人口"
info_population <- plyr::join(info_population, base_org, by = "orgid", type = "left") %>% unique()
All_POP <- length(unique(info_population$people_id))  
info_population$edulevelname <- info_population$edulevelname %>% educlean()
info_population$cardno <- info_population$cardno %>% substring(1,6)

lanzhou_coor <- base_chinacoordinate %>% filter(city == "兰州市")
base_org$codeno <- base_org$codeno %>% substring(1,6) 
base_org <- base_org %>% rename("coding_cnt" = "codeno") %>% plyr::join(lanzhou_coor, by = "coding_cnt", type = "left") %>% unique()
base_org <- ddply(base_org,.(orgid),function(x){ 
  s <- strsplit(x$orgpath, split = "\\.")
  x <- x %>% cbind(data.frame(n = length(s[[1]])))
  return(x)
})

base_org <- base_org %>% filter(n <= Travers_high, n >= Travers_low) %>% filter(!is.na(orgpath))


func <- function(n,base_org,info_population, Age_Divide,All_POP, age_interval,UN_Age_Divide,Edu_Level){
  library(plyr)
  library(dplyr)
  index <- grep(base_org$orgpath[n],base_org$orgpath)
  Cur_org <- base_org[index,]
  index <- info_population$orgid %in% Cur_org$orgid
  Cur_mem <- info_population[index,]
  if(nrow(Cur_mem) > 0){
    total_population <- length(unique(Cur_mem$people_id))
    resident_pop <- Cur_mem$name %>% plyr::count() %>% data.frame() %>% filter(x == "常住人口")
    if(nrow(resident_pop) == 0){
      resident_pop <- 0
    }else{
      resident_pop <- resident_pop$freq
    }
    mid_pop <- NA
    old_pop <- Cur_mem %>% filter(age >= Age_Divide[which(Age_Divide$age_name == Age_Divide$age_name[5]),]$age_low) %>% nrow()
    fig1 <- data.frame(orgid = rep(base_org$orgid[n],4), orgname = rep(base_org$orgname[n],4),orgpath = rep(base_org$orgpath[n],4), parentid = rep(base_org$parentid[n],4),
                       name = c("总人口","常住人口", "人口中位数","老年人口数量"), value = c(total_population,resident_pop,median(Cur_mem$age, na.rm = T), old_pop), date = Cur_mem$date[1])
    fig2 <- data.frame(orgid = base_org$orgid[n], orgname = base_org$orgname[n],orgpath = base_org$orgpath[n], parentid = base_org$parentid[n],
                       name = NA, value = total_population, ratio = total_population/length(unique(Cur_mem$people_id)),date = Cur_mem$date[1])
    
    childhood_pop <- Cur_mem %>% filter(age >= Age_Divide[which(Age_Divide$age_name == Age_Divide$age_name[1]),]$age_low, age <= Age_Divide[which(Age_Divide$age_name == Age_Divide$age_name[1]),]$age_high) %>% nrow()
    early_youth_pop <- Cur_mem %>% filter(age >= Age_Divide[which(Age_Divide$age_name == Age_Divide$age_name[2]),]$age_low, age <= Age_Divide[which(Age_Divide$age_name == Age_Divide$age_name[2]),]$age_high) %>% nrow()
    youth_pop <- Cur_mem %>% filter(age >= Age_Divide[which(Age_Divide$age_name == Age_Divide$age_name[3]),]$age_low, age <= Age_Divide[which(Age_Divide$age_name == Age_Divide$age_name[3]),]$age_high) %>% nrow()
    middle_age_pop <- Cur_mem %>% filter(age >= Age_Divide[which(Age_Divide$age_name == Age_Divide$age_name[4]),]$age_low,age <= Age_Divide[which(Age_Divide$age_name == Age_Divide$age_name[4]),]$age_high) %>% nrow()
    
    fig3 <- data.frame(orgid = base_org$orgid[n], orgname = base_org$orgname[n],orgpath = base_org$orgpath[n], parentid = base_org$parentid[n],
                       name = Age_Divide$age_name, value = c(childhood_pop,early_youth_pop,youth_pop,middle_age_pop,old_pop),
                       date = Cur_mem$date[1])
    if("男" %in% unique(Cur_mem$gender) && "女" %in% unique(Cur_mem$gender)){
      fig4 <- Cur_mem %>% plyr::count(c("gender", "age")) %>% data.frame() %>% filter(gender == c("女", "男"))
    }else if("男" %in% unique(Cur_mem$gender)){
      fig4 <- Cur_mem %>% plyr::count(c("gender", "age")) %>% data.frame() %>% filter(gender ==  "男")
    }else if("女" %in% unique(Cur_mem$gender)){
      fig4 <- Cur_mem %>% plyr::count(c("gender", "age")) %>% data.frame() %>% filter(gender ==  "女")
    }else{
      fig4 <- data.frame(gender = 0, age = 0)
      fig4 <- fig4[-1, ]
    }
    if(nrow(fig4) == 0){
      fig4 <- data.frame(gender = c("男","女"), age = 0,freq = 0)
    }else if(nrow(fig4[which(fig4$gender == "男"),])  == 0){
      fig4 <- data.frame(gender = "男", age = 0,freq = 0) %>% rbind(fig4)
    }else if (nrow(fig4[which(fig4$gender == "女"),])  == 0) {
      fig4 <- data.frame(gender = "女", age = 0,freq = 0) %>% rbind(fig4)
    }
    
    
    fig4 <- ddply(age_interval, .(interval), function(x,fig4,Cur_mem,base_org,n) data.frame(orgid = base_org$orgid[n], orgname = base_org$orgname[n],orgpath = base_org$orgpath[n], parentid = base_org$parentid[n],
                                                                                            name = x$interval, malecount = ifelse((fig4 %>%filter( gender == "男", age >= x$age_low, age <= x$age_high)%>% nrow()) > 0,
                                                                                                                                  sum((fig4 %>%filter( gender == "男", age >= x$age_low, age <= x$age_high))$freq),0),
                                                                                            femalecount = ifelse((fig4 %>%filter( gender == "女", age >= x$age_low, age <= x$age_high)%>% nrow()) > 0,
                                                                                                                 sum((fig4 %>%filter( gender == "女", age >= x$age_low, age <= x$age_high))$freq),0),
                                                                                            date = Cur_mem$date[1]),fig4,Cur_mem,base_org,n)
    fig5 <- Cur_mem$age %>% plyr::count() %>% data.frame() %>% rename("age" = "x", "value" = "freq")
    fig5 <- ddply(UN_Age_Divide, .(name), function(x,fig5,Cur_mem,base_org,n) data.frame(orgid = base_org$orgid[n], orgname = base_org$orgname[n],orgpath = base_org$orgpath[n], parentid = base_org$parentid[n],
                                                                                         name = x$name, value = ifelse((fig5 %>%filter( age >= x$age_low, age <= x$age_high)%>% nrow()) > 0,
                                                                                                                       sum((fig5 %>%filter(age >= x$age_low, age <= x$age_high))$value),0),
                                                                                         date = Cur_mem$date[1]),fig5,Cur_mem,base_org,n)
   
    fig6 <- Cur_mem[Cur_mem$edulevelname %in% Edu_Level$name,] 
    fig6 <- ddply(Edu_Level, .(name), function(x,fig6,Cur_mem,base_org,n) data.frame(orgid = base_org$orgid[n], orgname = base_org$orgname[n],orgpath = base_org$orgpath[n], parentid = base_org$parentid[n],
                                                                                     name = x$name, value = ifelse((fig6 %>%filter( edulevelname == x$name)%>% nrow()) > 0,
                                                                                                                   nrow(fig6 %>%filter( edulevelname == x$name)),0),
                                                                                     date = Cur_mem$date[1]),fig6,Cur_mem,base_org,n)
    other_pri_count <- Cur_mem[-grep("^62\\|^NA", Cur_mem$cardno),]$people_id %>% unique() %>% length() 
    other_cnt_count <- Cur_mem[-grep(base_org$coding_city[n],Cur_mem[grep("^62", Cur_mem$cardno),]$cardno),]$peopleid %>% unique() %>% length()
    local_count <- Cur_mem[grep(base_org$coding_cnt[n],Cur_mem[grep("^62", Cur_mem$cardno),]$cardno),]$peopleid %>% unique() %>% length()
    
    fig7 <- data.frame(orgid = base_org$orgid[n], orgname = base_org$orgname[n],orgpath = base_org$orgpath[n], parentid = base_org$parentid[n],
                       name = c("外省人口数量" ,"本省外地市人口数量" ,"本地人口数量"), value = c(other_pri_count,other_cnt_count,local_count),date = Cur_mem$date[1])
    return(list(fig1, fig2, fig3, fig4,fig5,fig6,fig7))
  }
  
  
}

system.time({
  
  n = 1:nrow(base_org)
  #--------------------------------------------------------------------------
  cores <- detectCores(logical = FALSE)
  cl <- makeCluster(cores)
  #--------------------------------------------------------------------------
  results <- parLapply(cl, n, func, base_org,info_population[,c("people_id","date", "age","name","cardno", "orgid", "gender","edulevelname")],Age_Divide,All_POP,age_interval,UN_Age_Divide,Edu_Level)
  fig1 <- ldply(results, function(y) rbind(y[[1]]))
  fig2 <- ldply(results, function(y) rbind(y[[2]]))
  fig3 <- ldply(results, function(y) rbind(y[[3]]))
  fig4 <- ldply(results, function(y) rbind(y[[4]]))
  fig5 <- ldply(results, function(y) rbind(y[[5]]))
  fig6 <- ldply(results, function(y) rbind(y[[6]]))
  fig7 <- ldply(results, function(y) rbind(y[[7]]))
  fig4$interval <- NULL
  
  
  stopCluster(cl)
})

#**************************************save hive***********************************************************************
cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names = T, recursive = T), recursive = T)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver", classPath = cp)
hiveconnection = RJDBC::dbConnect(drv, hive_url_out, user = hive_name, password = hive_password)
inserHiveFunctionV2(hiveconnection, hivedatabase, impalaurl, step = 10000,
                    fig1, out_table_fig1,
                    fig2, out_table_fig2,
                    fig3, out_table_fig3,
                    fig4, out_table_fig4,
                    fig5, out_table_fig5,
                    fig6, out_table_fig6,
                    fig7, out_table_fig7)

RJDBC::dbDisconnect(hiveconnection)
