#!/bin/bash
 
hive -e "CREATE DATABASE IF NOT EXISTS $1; DROP TABLE IF EXISTS $1.$3;
CREATE  TABLE $1.$3(rownames string,orgid string,orgname string,orgpath string,parentid string,lng double,lat double,value int,date string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:lng,cf:lat,cf:value,cf:date\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$3\"); 



DROP TABLE IF EXISTS $1.$4;
CREATE  TABLE $1.$4(rownames string,orgid string,orgname string,orgpath string,parentid string,name string,value int,date string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:value,cf:date\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$4\");

DROP TABLE IF EXISTS $1.$5;
CREATE  TABLE $1.$5(rownames string,orgid string,orgname string,orgpath string,parentid string,name string,value int,date string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:value,cf:date\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$5\");

DROP TABLE IF EXISTS $1.$6;
CREATE  TABLE $1.$6(rownames string,orgid string,orgname string,orgpath string,parentid string,name string,value double,date string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:value,cf:date\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$6\");



"

impala-shell -i $2 -q "INVALIDATE METADATA" 
