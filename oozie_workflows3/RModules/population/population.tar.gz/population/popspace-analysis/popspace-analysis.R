rm(list = ls())
graphics.off()

library(plyr)
library(dplyr)
library(RJDBC)
library(rjson)
library(timeDate)
library(rgdal)
library(stringr)
library(doParallel)
options(scipen = 20)

argv <- commandArgs(TRUE)
Cur_Path = as.character(argv[1])
json_path <- paste(Cur_Path,"../../shared_lib/getconfig.R",sep = "/")
# json_path <- "/data/home/zhaochuanhu/development/population_v3/shared_lib/getconfig.R"
# Cur_Path <- "/data/home/zhaochuanhu/development/population_v3/base_people_preprocess/popspace-analysis/"
source(json_path)
json_data <- getconfig(Cur_Path)
json_name=names(json_data)

runtype = as.numeric(json_data[which(json_name == "runtype")])#runtype=1为R调用模式，否则为Java命令行调用模式
dsn_name = as.character(json_data[which(json_name == "dsn")])
uid_name = as.character(json_data[which(json_name == "uid")])
pwd_name = as.character(json_data[which(json_name == "pwd")])

Travers_low <- as.numeric(json_data[which(json_name == "Travers_low")])
Travers_high <- as.numeric(json_data[which(json_name == "Travers_high")])
older_Age_low <- as.numeric(json_data[which(json_name == "older_Age_low")])
older_Age_high <- as.numeric(json_data[which(json_name == "older_Age_high")])
preschool_age_low <- as.numeric(json_data[which(json_name == "preschool_age_low")])
preschool_age_high <- as.numeric(json_data[which(json_name == "preschool_age_high")])
marry_level = as.character(json_data[which(json_name=="marry_level")])
nation_level = as.character(json_data[which(json_name=="nation_level")])

in_table_r_familyinfo = as.character(json_data[which(json_name=="in_table_r_familyinfo")])
tablename_baseorg = as.character(json_data[which(json_name=="in_table_baseorg")])
in_table_base_polygons = as.character(json_data[which(json_name=="in_table_base_polygons")])
tablename_r_people = as.character(json_data[which(json_name=="in_table_r_people")])

out_table_fig1 = as.character(json_data[which(json_name=="out_table_fig1")])
out_table_fig2= as.character(json_data[which(json_name=="out_table_fig2")])
out_table_fig3 = as.character(json_data[which(json_name=="out_table_fig3")])
out_table_fig4 = as.character(json_data[which(json_name=="out_table_fig4")])
out_table_fig5 = as.character(json_data[which(json_name=="out_table_fig5")])
out_table_fig6 = as.character(json_data[which(json_name=="out_table_fig6")])
out_table_fig7 = as.character(json_data[which(json_name=="out_table_fig7")])
out_table_fig8 = as.character(json_data[which(json_name=="out_table_fig8")])
out_table_fig9 = as.character(json_data[which(json_name=="out_table_fig9")])
# READ HIVE ************************************************************
impalaurl <- as.character(json_data[["impalaurl"]])
hive_driver_path <- as.character(json_data[["hivedriver"]])
hive_name <- as.character(json_data[["hiveuser"]])
hive_password <- as.character(json_data[["hivepassword"]])
hive_url_in <- as.character(json_data[["hiveurlin"]])
hive_url_out <- as.character(json_data[["hiveurlout"]])
hivedatabase <- unlist(strsplit(hive_url_out,'/'))
hivedatabase <- hivedatabase[length(hivedatabase)]
# READ HIVE ************************************************************

# READ HIVE ****************************************************************
cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url_in,user=hive_name, password=hive_password)

r_familyinfo <- RJDBC::dbGetQuery(hiveconnection,paste("select peopleid, buildingid,liveaddress,orgid, orgpath, createtime as date   from ", in_table_r_familyinfo, sep = ""))
base_org <- RJDBC::dbGetQuery(hiveconnection,paste("select id as orgid, parentid,path as orgpath, orgname, codeno from ", tablename_baseorg, sep = ""))
rlt_base_polygons <- RJDBC::dbGetQuery(hiveconnection,paste("select id as buildingid , center_lng, center_lat from ", in_table_base_polygons, sep = ""))
r_people <- RJDBC::dbGetQuery(hiveconnection,paste("select id as peopleid, gender, birthday as birthday ,nationname, marryname from ", tablename_r_people, sep = ""))

RJDBC::dbDisconnect(hiveconnection)
# load("/data/home/zhaochuanhu/development/population_v3/temp_data/base_org.RData")
# load("/data/home/zhaochuanhu/development/population_v3/temp_data/r_people.RData")
#***********************************************************************************************
base_info <- r_familyinfo %>% join(rlt_base_polygons, by = "buildingid", type = "left") %>% join(r_people,by = "peopleid", type = "left")%>% unique()
base_info$liveaddress <- str_extract(base_info$liveaddress,"[0-9]+层")
base_info$date <- base_info$date %>% substring(1,7)
base_info$birthday <- base_info$birthday %>% substring(1,4) %>% as.numeric()
base_info$age <- (timeDate() %>% substring(1,4) %>% as.numeric()) - base_info$birthday
marry_level_factor <- unlist(strsplit(marry_level,split = ","))
nation_level_factor <- unlist(strsplit(nation_level,split = ","))


base_org <- ddply(base_org,.(orgid),function(x){ 
  s <- strsplit(x$orgpath, split = "\\.")
  x <- x %>% cbind(data.frame(n = length(s[[1]])))
  return(x)
})

base_org <- base_org %>% filter(n <= Travers_high, n >= Travers_low) %>% filter(!is.na(orgpath))




func <- function(n,base_org, base_info, older_Age_low,older_Age_high,preschool_age_low,preschool_age_high,marry_level_factor,nation_level_factor){
  library(plyr)
  library(dplyr)
  index <- grep(base_org$orgpath[n],base_info$orgpath)
  Cur_org <- base_org[index,]
  index <- base_info$orgid %in% Cur_org$orgid
  Cur_mem <- base_info[index,]
  if(nrow(Cur_mem) > 0){
    
    
    fig1 <- Cur_mem %>% plyr::count(c("center_lng", "center_lat")) %>% data.frame() %>% rename("value" = "freq")
    fig1 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig1)), orgname = rep(base_org$orgname[n],nrow(fig1)),orgpath = rep(base_org$orgpath[n],nrow(fig1)), 
                       parentid = rep(base_org$parentid[n],nrow(fig1)),date = rep(Cur_mem$date[1],nrow(fig1))) %>% cbind(fig1)
    fig2 <- Cur_mem %>% filter(age >= 66)
    fig2 <- fig2 %>% plyr::count(c("center_lng", "center_lat")) %>% data.frame() %>% rename("value" = "freq")
    fig2 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig2)), orgname = rep(base_org$orgname[n],nrow(fig2)),orgpath = rep(base_org$orgpath[n],nrow(fig2)), 
                       parentid = rep(base_org$parentid[n],nrow(fig2)),date = rep(Cur_mem$date[1],nrow(fig2))) %>% cbind(fig2)
    
    fig3 <- Cur_mem %>% filter(age >= preschool_age_low, age < preschool_age_high)
    fig3 <- fig3 %>% plyr::count(c("center_lng", "center_lat")) %>% data.frame() %>% rename("value" = "freq")
    fig3 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig3)), orgname = rep(base_org$orgname[n],nrow(fig3)),orgpath = rep(base_org$orgpath[n],nrow(fig3)), 
                       parentid = rep(base_org$parentid[n],nrow(fig3)),date = rep(Cur_mem$date[1],nrow(fig3))) %>% cbind(fig3)
    
    fig4 <- Cur_mem %>% filter(age >= older_Age_low, age <= older_Age_high) %>%
      plyr::count("age") %>% data.frame() %>% rename("name"= "age","value" = "freq")
    fig4 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig4)), orgname = rep(base_org$orgname[n],nrow(fig4)),orgpath = rep(base_org$orgpath[n],nrow(fig4)), 
                       parentid = rep(base_org$parentid[n],nrow(fig4)),date = rep(Cur_mem$date[1],nrow(fig4))) %>% cbind(fig4)
    
    fig5 <- Cur_mem %>% filter(age >= preschool_age_low, age < preschool_age_high) %>%
      plyr::count("age") %>% data.frame() %>% rename("name" = "age","value" = "freq")
    fig5 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig5)), orgname = rep(base_org$orgname[n],nrow(fig5)),orgpath = rep(base_org$orgpath[n],nrow(fig5)), 
                       parentid = rep(base_org$parentid[n],nrow(fig5)),date = rep(Cur_mem$date[1],nrow(fig5))) %>% cbind(fig5)
    
    fig6 <- Cur_mem[Cur_mem$marryname %in% marry_level_factor, ] %>% filter(age >= older_Age_low, age <= older_Age_high) %>%
      plyr::count("marryname") %>% data.frame() %>% rename("name" = "marryname","value" = "freq")
    fig6 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig6)), orgname = rep(base_org$orgname[n],nrow(fig6)),orgpath = rep(base_org$orgpath[n],nrow(fig6)), 
                       parentid = rep(base_org$parentid[n],nrow(fig6)),date = rep(Cur_mem$date[1],nrow(fig6))) %>% cbind(fig6)
    
    fig7 <- Cur_mem[Cur_mem$nationname %in% nation_level_factor, ] %>% filter(age >= older_Age_low, age <= older_Age_high) %>%
      plyr::count("nationname") %>% data.frame() %>% rename("name" = "nationname","value" = "freq")
    fig7 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig7)), orgname = rep(base_org$orgname[n],nrow(fig7)),orgpath = rep(base_org$orgpath[n],nrow(fig7)), 
                       parentid = rep(base_org$parentid[n],nrow(fig7)),date = rep(Cur_mem$date[1],nrow(fig7))) %>% cbind(fig7)
    
    fig8 <- Cur_mem[Cur_mem$gender %in% c("男","女"), ] %>% filter(age >= preschool_age_low, age < preschool_age_high) %>%
      plyr::count("gender") %>% data.frame() %>% rename("name" = "gender","value" = "freq")
    fig8 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig8)), orgname = rep(base_org$orgname[n],nrow(fig8)),orgpath = rep(base_org$orgpath[n],nrow(fig8)), 
                       parentid = rep(base_org$parentid[n],nrow(fig8)),date = rep(Cur_mem$date[1],nrow(fig8))) %>% cbind(fig8)
    
    fig9 <- Cur_mem[Cur_mem$nationname %in% nation_level_factor, ] %>% filter(age >= preschool_age_low, age < preschool_age_high) %>%
      plyr::count("nationname") %>% data.frame() %>% rename("name" = "nationname","value" = "freq")
    fig9 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig9)), orgname = rep(base_org$orgname[n],nrow(fig9)),orgpath = rep(base_org$orgpath[n],nrow(fig9)), 
                       parentid = rep(base_org$parentid[n],nrow(fig9)),date = rep(Cur_mem$date[1],nrow(fig9))) %>% cbind(fig9)
    
    return(list(fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9))
  }
  
  
}

system.time({
  
  n = 1:nrow(base_org)
  #--------------------------------------------------------------------------
  cores <- detectCores(logical = FALSE)
  cl <- makeCluster(cores)
  #--------------------------------------------------------------------------
  results <- parLapply(cl, n, func, base_org,base_info, older_Age_low, older_Age_high,preschool_age_low,preschool_age_high,marry_level_factor,nation_level_factor)
  fig1 <- ldply(results, function(y) rbind(y[[1]]))
  fig2 <- ldply(results, function(y) rbind(y[[2]]))
  fig3 <- ldply(results, function(y) rbind(y[[3]]))
  fig4 <- ldply(results, function(y) rbind(y[[4]]))
  fig5 <- ldply(results, function(y) rbind(y[[5]]))
  fig6 <- ldply(results, function(y) rbind(y[[6]]))
  fig7 <- ldply(results, function(y) rbind(y[[7]]))
  fig8 <- ldply(results, function(y) rbind(y[[8]]))
  fig9 <- ldply(results, function(y) rbind(y[[9]]))
  
  
  stopCluster(cl)
})
############################################################################################################
cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names = T, recursive = T), recursive = T)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver", classPath = cp)
hiveconnection = RJDBC::dbConnect(drv, hive_url_out, user = hive_name, password = hive_password)
inserHiveFunctionV2(hiveconnection, hivedatabase, impalaurl, step = 10000,
                    
                    fig1, out_table_fig1,
                    fig2, out_table_fig2,
                    fig3, out_table_fig3,
                    fig4, out_table_fig4,
                    
                    fig5, out_table_fig5,
                    fig6, out_table_fig6,
                    fig7, out_table_fig7,
                    fig8, out_table_fig8,
                    fig9, out_table_fig9)

RJDBC::dbDisconnect(hiveconnection)