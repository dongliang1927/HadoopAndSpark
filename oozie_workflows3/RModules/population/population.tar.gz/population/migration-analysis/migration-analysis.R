rm(list = ls())
graphics.off()
options(scipen = 20)

library(plyr)
library(timeDate)
library(RJDBC)
library(rjson)
library(rgdal)
library(dplyr)
library(doParallel)

argv <- commandArgs(TRUE)
Cur_Path = as.character(argv[1])
json_path <- paste(Cur_Path,"../../shared_lib/getconfig.R",sep = "/")

# json_path <- "/data/home/zhaochuanhu/development/population_v3/shared_lib/getconfig.R"
# Cur_Path <- "/data/home/zhaochuanhu/development/population_v3/base_people_preprocess/migration-analysis/"
source(json_path)
json_data <- getconfig(Cur_Path)
json_name=names(json_data)

runtype = as.numeric(json_data[which(json_name == "runtype")])#runtype=1为R调用模式，否则为Java命令行调用模式
dsn_name = as.character(json_data[which(json_name == "dsn")])
uid_name = as.character(json_data[which(json_name == "uid")])
pwd_name = as.character(json_data[which(json_name == "pwd")])

tablename_r_people = as.character(json_data[which(json_name=="in_table_r_people")])
Base_china = as.character(json_data[which(json_name=="in_table_base_chinacoordinate")])
tablename_baseorg = as.character(json_data[which(json_name=="in_table_baseorg")])
rlt_base_polygons = as.character(json_data[which(json_name=="in_table_rlt_base_polygons")])
PRINCE = as.character(json_data[which(json_name=="PRINCE")])
Travers_low <- as.numeric(json_data[which(json_name == "Travers_low")])
Travers_high <- as.numeric(json_data[which(json_name == "Travers_high")])
marry_level = as.character(json_data[which(json_name=="marry_level")])


out_table_fig1 = as.character(json_data[which(json_name=="out_table_fig1")])
out_table_fig2 = as.character(json_data[which(json_name=="out_table_fig2")])
out_table_fig3 = as.character(json_data[which(json_name=="out_table_fig3")])
out_table_fig4 = as.character(json_data[which(json_name=="out_table_fig4")])
out_table_fig5 = as.character(json_data[which(json_name=="out_table_fig5")])
# READ HIVE ************************************************************
impalaurl <- as.character(json_data[["impalaurl"]])
hive_driver_path <- as.character(json_data[["hivedriver"]])
hive_name <- as.character(json_data[["hiveuser"]])
hive_password <- as.character(json_data[["hivepassword"]])
hive_url_in <- as.character(json_data[["hiveurlin"]])
hive_url_out <- as.character(json_data[["hiveurlout"]])
hivedatabase <- unlist(strsplit(hive_url_out,'/'))
hivedatabase <- hivedatabase[length(hivedatabase)]
# READ HIVE ************************************************************

# READ HIVE ****************************************************************
cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url_in,user=hive_name, password=hive_password)

r_people <- RJDBC::dbGetQuery(hiveconnection,paste("select id as peopleid,birthday,gender ,marryname as marryname,certificateid as cardnum, orgid  from ", tablename_r_people, sep = ""))
base_org <- RJDBC::dbGetQuery(hiveconnection,paste("select base_org.id as orgid,parentid,base_org.path as orgpath, orgname from ", tablename_baseorg, sep = ""))
base_chinacoodinate <- RJDBC::dbGetQuery(hiveconnection,paste("select prince as prince ,coding_prn as coding_prn,county as county,coding_cnt as coding_cnt,lng as lng,lat as lat from ", Base_china, sep = ""))
rlt_base_polygons <- RJDBC::dbGetQuery(hiveconnection,paste("select  orgid, center_lng, center_lat from ", rlt_base_polygons, sep = ""))
RJDBC::dbDisconnect(hiveconnection)
############################################################################################################################
base_info <- r_people
base_info$coding_prn <-  base_info$cardnum %>% substring(1,2)
base_info$coding_cnt <-  base_info$cardnum %>% substring(1,4)
base_info$cardnum <- NULL
# base_info <- base_info %>% join(base_org[,c("orgid", "orgpath")], by = "orgid", type = "left")
base_info$birthday <- base_info$birthday %>% substring(1,4) %>% as.numeric()
base_info$age <- (timeDate() %>% substring(1,4) %>% as.numeric()) - base_info$birthday
base_info$birthday <- NULL

prince_info <- base_chinacoodinate[grep("0000$|0100$", base_chinacoodinate$coding_cnt),]
country_info <- base_chinacoodinate %>% filter(prince == PRINCE) 
country_info <- country_info[grep("00$", country_info$coding_cnt),]  %>% rename("cnt_lng" = "lng", "cnt_lat" = "lat")
country_info$coding_cnt <- country_info$coding_cnt %>% substring(1,4)
marry_level_factor <- unlist(strsplit(marry_level,split = ","))

# base_chinacoodinate$coding_prn <- base_chinacoodinate$coding_cnt %>% substring(1,2)
# base_chinacoodinate$coding_cnt <- base_chinacoodinate$coding_cnt %>% substring(1,4)
base_org <- base_org %>% plyr::join(rlt_base_polygons, by = "orgid", type = "left", match = "first") %>% unique()
base_info <-base_info %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") %>% unique()
base_info <-base_info %>% join(country_info[,c("county", "coding_cnt", "cnt_lng", "cnt_lat")], by = "coding_cnt", type = "left") %>% unique()

base_org <- ddply(base_org,.(orgid),function(x){ 
  s <- strsplit(x$orgpath, split = "\\.")
  x <- x %>% cbind(data.frame(n = length(s[[1]])))
  return(x)
})

base_org <- base_org %>% filter(n <= Travers_high, n >= Travers_low) %>% filter(!is.na(orgpath))
# base_info$orgpath <- NULL
base_info$coding_prn <- NULL
base_info$coding_cnt <- NULL
func <- function(n,base_org, base_info,PRINCE,marry_level_factor){
  library(plyr)
  library(dplyr)
  index <- grep(base_org$orgpath[n],base_org$orgpath)
  Cur_org <- base_org[index,]
  index <- base_info$orgid %in% Cur_org$orgid
  Cur_mem <- base_info[index,]
  if(nrow(Cur_mem) > 0){
    
    # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") %>% unique()
    if((Cur_mem %>% filter(prince != PRINCE) %>% nrow()) > 0){
      # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") 
      fig1 <- Cur_mem %>% filter(prince != PRINCE) %>% plyr::count(c("prince", "lng", "lat")) %>% data.frame() %>% rename("sourcelng" = "lng","sourcename" = "prince","sourcelat" = "lat", "value" = "freq")
      fig1 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig1)), orgname = rep(base_org$orgname[n],nrow(fig1)),orgpath = rep(base_org$orgpath[n],nrow(fig1)), 
                         parentid = rep(base_org$parentid[n],nrow(fig1)),
                         dstlng = base_org$center_lng[n], dstlat = base_org$center_lat[n],
                         dstname = base_org$orgname[n],type = 1) %>% cbind(fig1)
    }else{
      fig1 <- data.frame(orgid = 0, orgname = 0,orgpath  = 0,parentid = 0,dstlng = 0,dstlat = 0,
                         dstname = 0,type = 0,sourcename = 0,sourcelng = 0,sourcelat = 0,value = 0)
      fig1 <- fig1[-1,]
    }
    
    # tmp <- Cur_mem %>% join(country_info[,c("county", "coding_cnt", "lng", "lat")], by = "coding_cnt", type = "left") %>% unique()
    if((Cur_mem %>% filter(county != "兰州市") %>% nrow()) > 0){
      
      # tmp <- Cur_mem %>% join(country_info[,c("county", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") 
      fig <- Cur_mem %>% filter(county != "兰州市")%>% plyr::count(c("county", "cnt_lng", "cnt_lat")) %>% data.frame() %>% rename("sourcelng" = "cnt_lng","sourcename" = "county","sourcelat" = "cnt_lat", "value" = "freq")
      fig1 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig)), orgname = rep(base_org$orgname[n],nrow(fig)),orgpath = rep(base_org$orgpath[n],nrow(fig)), 
                         parentid = rep(base_org$parentid[n],nrow(fig)),
                         dstlng = base_org$center_lng[n], dstlat = base_org$center_lat[n],
                         dstname = base_org$orgname[n],type = 0) %>% cbind(fig) %>% rbind(fig1)
    }else{
      fig <- data.frame(orgid = 0, orgname = 0,orgpath  = 0,parentid = 0,dstlng = 0,dstlat = 0,
                        dstname = 0,type = 0,sourcename = 0,sourcelng = 0,sourcelat = 0,value = 0)
      fig1 <- fig[-1,] %>% rbind(fig1)
    }
    
    # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn")], by = "coding_prn", type = "left") %>% unique()
    if((Cur_mem %>% filter(prince != PRINCE) %>% nrow()) > 0){
      # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") 
      fig2 <- Cur_mem %>% filter(prince != PRINCE) %>% plyr::count("gender") %>% data.frame() %>% rename( "name" = "gender","value" = "freq") %>% filter(name == "男" | name == "女")
      fig2 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig2)), orgname = rep(base_org$orgname[n],nrow(fig2)),orgpath = rep(base_org$orgpath[n],nrow(fig2)), 
                         parentid = rep(base_org$parentid[n],nrow(fig2)),type = 1) %>% cbind(fig2)
    }else{
      fig2 <- data.frame(orgid = 0, orgname = 0,orgpath = 0, 
                         parentid = 0,type = 1,name = 0,value = 0)
      fig2 <- fig2[-1,]
    }
    # tmp <- Cur_mem %>% join(country_info[,c("county", "coding_cnt")], by = "coding_cnt", type = "left") %>% unique()
    if((Cur_mem %>% filter(county != "兰州市") %>% nrow()) > 0){
      # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") 
      fig <- Cur_mem%>% filter(county != "兰州市") %>% plyr::count("gender") %>% data.frame() %>% rename( "name" = "gender","value" = "freq") %>% filter(name == "男" | name == "女")
      fig2 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig)), orgname = rep(base_org$orgname[n],nrow(fig)),orgpath = rep(base_org$orgpath[n],nrow(fig)), 
                         parentid = rep(base_org$parentid[n],nrow(fig)),type = 0) %>% cbind(fig) %>% rbind(fig2)
    }else{
      fig <- data.frame(orgid = 0, orgname = 0,orgpath = 0, 
                        parentid = 0,type = 0,name = 0,value = 0)
      fig2 <- fig[-1,]%>% rbind(fig2)
    }
    
    # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn")], by = "coding_prn", type = "left") %>% unique()
    if((Cur_mem %>% filter(prince != PRINCE) %>% nrow()) > 0){
      # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") 
      fig3 <- Cur_mem %>% filter(prince != PRINCE) %>% plyr::count("age") %>% data.frame() %>% rename( "name" = "age","value" = "freq")
      fig3 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig3)), orgname = rep(base_org$orgname[n],nrow(fig3)),orgpath = rep(base_org$orgpath[n],nrow(fig3)), 
                         parentid = rep(base_org$parentid[n],nrow(fig3)),type = 1) %>% cbind(fig3)
    }else{
      fig3 <- data.frame(orgid = 0, orgname = 0,orgpath = 0, 
                         parentid = 0,type = 1,name = 0,value = 0)
      fig3 <- fig3[-1,]
    }
    # tmp <- Cur_mem %>% join(country_info[,c("county", "coding_cnt")], by = "coding_cnt", type = "left") %>% unique()
    if((Cur_mem %>% filter(county != "兰州市") %>% nrow()) > 0){
      # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") 
      fig <- Cur_mem %>% filter(county != "兰州市") %>% plyr::count("age") %>% data.frame() %>% rename( "name" = "age","value" = "freq")
      fig3 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig)), orgname = rep(base_org$orgname[n],nrow(fig)),orgpath = rep(base_org$orgpath[n],nrow(fig)), 
                         parentid = rep(base_org$parentid[n],nrow(fig)),type = 0) %>% cbind(fig) %>% rbind(fig3)
    }else{
      fig <- data.frame(orgid = 0, orgname = 0,orgpath = 0, 
                        parentid = 0,type = 0,name = 0,value = 0)
      fig3 <- fig[-1,]%>% rbind(fig3)
    }
    
    # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn")], by = "coding_prn", type = "left") %>% unique()
    Cur_mem <- Cur_mem[Cur_mem$marryname %in% marry_level_factor,]
    if((Cur_mem %>% filter(prince != PRINCE) %>% nrow()) > 0){
      # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left")
      fig4 <- Cur_mem %>% filter(prince != PRINCE) %>% plyr::count("marryname") %>% data.frame() %>% rename( "name" = "marryname","value" = "freq")
      fig4 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig4)), orgname = rep(base_org$orgname[n],nrow(fig4)),orgpath = rep(base_org$orgpath[n],nrow(fig4)), 
                         parentid = rep(base_org$parentid[n],nrow(fig4)),type = 1) %>% cbind(fig4)
    }else{
      fig4 <- data.frame(orgid = 0, orgname = 0,orgpath = 0, 
                         parentid = 0,type = 1,name = 0,value = 0)
      fig4 <- fig4[-1,]
    }
    
    # tmp <- Cur_mem %>% join(country_info[,c("county", "coding_cnt")], by = "coding_cnt", type = "left") %>% unique()
    Cur_mem <- Cur_mem[Cur_mem$marryname %in% marry_level_factor,]
    if((Cur_mem %>% filter(county != "兰州市") %>% nrow()) > 0){
      # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") 
      fig <- Cur_mem %>% filter(county != "兰州市") %>% plyr::count("marryname") %>% data.frame() %>% rename( "name" = "marryname","value" = "freq")
      fig4 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig)), orgname = rep(base_org$orgname[n],nrow(fig)),orgpath = rep(base_org$orgpath[n],nrow(fig)), 
                         parentid = rep(base_org$parentid[n],nrow(fig)),type = 0) %>% cbind(fig) %>% rbind(fig4)
    }else{
      fig <- data.frame(orgid = 0, orgname = 0,orgpath = 0, 
                        parentid = 0,type = 0,name = 0,value = 0)
      fig4 <- fig[-1,]%>% rbind(fig4)
    }
    
    
    # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn")], by = "coding_prn", type = "left") %>% unique()
    if((Cur_mem %>% filter(prince != PRINCE) %>% nrow()) > 0){
      # tmp <- Cur_mem %>% join(prince_info[,c("prince", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") 
      fig5 <- Cur_mem %>% filter(prince != PRINCE) %>% plyr::count(c("prince")) %>% data.frame() %>% rename("name" = "prince", "value" = "freq")
      fig5 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig5)), orgname = rep(base_org$orgname[n],nrow(fig5)),orgpath = rep(base_org$orgpath[n],nrow(fig5)), 
                         parentid = rep(base_org$parentid[n],nrow(fig5)),type = 1) %>% cbind(fig5)
    }else{
      fig5 <- data.frame(orgid = 0, orgname = 0,orgpath = 0, 
                         parentid = 0,type = 1,name = 0, value = 0)
      fig5 <- fig5[-1,]
    }
    
    # tmp <- Cur_mem %>% join(country_info[,c("county", "coding_cnt", "lng", "lat")], by = "coding_cnt", type = "left") %>% unique()
    if((Cur_mem %>% filter(county != "兰州市") %>% nrow()) > 0){
      
      # tmp <- Cur_mem %>% join(country_info[,c("county", "coding_prn", "lng", "lat")], by = "coding_prn", type = "left") 
      fig <- Cur_mem %>% filter(county != "兰州市")%>% plyr::count(c("county")) %>% data.frame() %>% rename("name" = "county", "value" = "freq")
      fig5 <- data.frame(orgid = rep(base_org$orgid[n],nrow(fig)), orgname = rep(base_org$orgname[n],nrow(fig)),orgpath = rep(base_org$orgpath[n],nrow(fig)), 
                         parentid = rep(base_org$parentid[n],nrow(fig)),
                         type = 0) %>% cbind(fig) %>% rbind(fig5)
    }else{
      fig <- data.frame(orgid = 0, orgname = 0,orgpath  = 0,parentid = 0,
                        type = 0,name = 0,value = 0)
      fig5 <- fig[-1,] %>% rbind(fig5)
    }
    
    return(list(fig1, fig2, fig3, fig4, fig5))
  }
  
  
}

system.time({
  
  n = 1:nrow(base_org)
  #--------------------------------------------------------------------------
  cores <- detectCores(logical = FALSE)
  cl <- makeCluster(cores)
  #--------------------------------------------------------------------------
  results <- parLapply(cl, n, func, base_org,base_info,PRINCE,marry_level_factor)
  fig1 <- ldply(results, function(y) rbind(y[[1]]))
  fig2 <- ldply(results, function(y) rbind(y[[2]]))
  fig3 <- ldply(results, function(y) rbind(y[[3]]))
  fig4 <- ldply(results, function(y) rbind(y[[4]]))
  fig5 <- ldply(results, function(y) rbind(y[[5]]))
  # 
  
  
  stopCluster(cl)
})


# system.time({
#   
#   n = 1:nrow(base_org)
#   #--------------------------------------------------------------------------
#   cores <- detectCores(logical = FALSE)
#   cl <- makeCluster(cores)
#   #--------------------------------------------------------------------------
#   results <- parLapply(cl, n, func, base_org,base_info,PRINCE,country_info,prince_info,marry_level_factor)
#   fig1 <- ldply(results, function(y) rbind(y[[1]]))
#   fig2 <- ldply(results, function(y) rbind(y[[2]]))
#   fig3 <- ldply(results, function(y) rbind(y[[3]]))
#   fig4 <- ldply(results, function(y) rbind(y[[4]]))
#   fig5 <- ldply(results, function(y) rbind(y[[5]]))
#   # 
#   
#   
#   stopCluster(cl)
# })


#**************************************save hive***********************************************************************
cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names = T, recursive = T), recursive = T)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver", classPath = cp)
hiveconnection = RJDBC::dbConnect(drv, hive_url_out, user = hive_name, password = hive_password)
inserHiveFunctionV2(hiveconnection, hivedatabase, impalaurl, step = 10000,

                    fig1, out_table_fig1,
                    fig2, out_table_fig2,
                    fig3, out_table_fig3,
                    fig4, out_table_fig4,
                    fig5, out_table_fig5)

RJDBC::dbDisconnect(hiveconnection)

