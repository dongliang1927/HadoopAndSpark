#!/bin/bash
 
hive -e "CREATE DATABASE IF NOT EXISTS $1; DROP TABLE IF EXISTS $1.$3;
CREATE  TABLE $1.$3(rownames string,orgid string,orgname string,orgpath string,parentid string,sourcelng double,sourcelat double,sourcename string,dstname string,dstlng double,dstlat double,value int,type int)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:sourcelng,cf:sourcelat,cf:sourcename,cf:dstname,cf:dstlng,cf:dstlat,cf:value,cf:type\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$3\"); 

DROP TABLE IF EXISTS $1.$4;
CREATE  TABLE $1.$4(rownames string,orgid string,orgname string,orgpath string,parentid string,name string,value double,type int)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:value,cf:type\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$4\");

DROP TABLE IF EXISTS $1.$5;
CREATE  TABLE $1.$5(rownames int,orgid string,orgname string,orgpath string,parentid string,name string,value double,type int)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:value,cf:type\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$5\");

DROP TABLE IF EXISTS $1.$6;
CREATE  TABLE $1.$6(rownames int,orgid string,orgname string,orgpath string,parentid string,name string,value double,type int)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:value,cf:type\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$6\");

DROP TABLE IF EXISTS $1.$7;
CREATE  TABLE $1.$7(rownames int,orgid string,orgname string,orgpath string,parentid string,name string,value double,type int)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:orgid,cf:orgname,cf:orgpath,cf:parentid,cf:name,cf:value,cf:type\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$7\");


"

impala-shell -i $2 -q "INVALIDATE METADATA" 
