

# Description -------------------------------------------------------------
#本函数实现
# 1、可以读取global、topic、module层次下的json
# 2、实现深层次的json文件覆盖上级json文件
#
# Description -------------------------------------------------------------
getconfig <- function(Cur_Path){
  library(rjson)
  library(ttutils)
  
  json_path_module <- paste(Cur_Path,"config.json",sep = "/")
  json_path_global <- paste(Cur_Path,"../../config.json",sep = "/")

  if(file.exists(json_path_global)){
    json_data_global <- tryCatch({
      fromJSON(paste(readLines(json_path_global),collapse =""))
    },error = function(e){
      print(e)
      print("warning:global模块json文件为空。")
      list()
    })
  }else{
    json_data_global <- list()
  }
  if(file.exists(json_path_module)){
    json_data_module <- tryCatch({
      fromJSON(paste(readLines(json_path_module),collapse =""))
    },error = function(e){
      print(e)
      print("warning:module模块json文件为空。")
      list()
    })
  }else{
    json_data_module <- list()
  }
  json_data <- merge(json_data_module,json_data_global)
  if(length(json_data)==0){
    print("error:调用shared_lib模块函数getconfig时，返回空值，请检查当前路径问题")
  }
  
  return(json_data)
  
}

HiveInsertFunc <- function(hiveconnection,inputtable,outputtable,impalaurl,step=1000){
  # HiveInsertFunc <- function(hiveconnection,inputtable,outputtable,n=1){
  # # 连接，输入框名，输出表名，分n次写入
  #该函数实现，将结果表写入Hive表中
  # Village_name <- inputtable
  for(eachcolname in names(inputtable)){
    inputtable[,eachcolname] <- gsub("'","***",as.character(inputtable[,eachcolname]))
    inputtable[,eachcolname] <- gsub("\\","***",as.character(inputtable[,eachcolname]),fixed=TRUE)
  }
  
  out_table_information_in <- outputtable
  hiveconnection <- hiveconnection
  m <- ceiling(nrow(inputtable)/step)
  startrow <- 1  
  for(eachnrow in 1:m){
    Village_name <- inputtable[(startrow:(startrow + step-1)),]
    Village_name <- Village_name[!is.na(Village_name$rownames),]
    startrow <- startrow + step
    finalStr <- "paste(Village_name[,1]"
    for (i in 2:(length(Village_name))){
      finalStr <- paste(finalStr,",Village_name[,",i,"]",sep="")
    }
    finalStr <- paste(finalStr,",sep=\"','\",collapse = \"'),('\")")
    sql_values <- paste("('",eval(parse(text = finalStr)),"')",sep="")
    columnames <- paste("(",paste(names(inputtable),collapse = ",",sep=""),")",sep="")
    insertsql <- paste("insert into ",out_table_information_in,columnames," values ",sql_values,sep="")
    insertsql_clean <- gsub("[^[:print:]]", "",insertsql)
    result <- RJDBC::dbSendUpdate(hiveconnection,insertsql_clean)
  }
  system(paste("impala-shell -i ",impalaurl," -q \"INVALIDATE METADATA\"",sep="") )
  print("DONE")
}

inserHiveFunctionV2 <- function(hiveconnection,hivedatabase,impalaurl,step=10000,...){
  cmd <- paste(Cur_Path,"/createHiveTable.sh ",hivedatabase," ",impalaurl,sep="")
  if(length(list(...))>0){
    arg <- list(...)
    for(eachindex in 1:length(arg)){
      if(eachindex %%2 ==0){
        cmd <- paste(cmd,arg[[eachindex]],sep=" ")
      }
    }
    system(cmd)
  }else{
    stop("input args wrong..")
  }
  if(length(list(...))>0){
    arg <- list(...)
    for(eachindex in 1:length(arg)){
      if(eachindex %%2 !=0){
        
        result_dataframe <- arg[[eachindex]]
        result_database <- arg[[eachindex+1]]
        result_dataframe$rownames <- 1:nrow(result_dataframe)
        
        intable <- result_dataframe
        HiveInsertFunc(hiveconnection,intable,result_database,impalaurl,step)
        print(paste("inserted into table:",arg[[eachindex+1]]))
      }
    }
  }else{
    stop("input args wrong..")
  }

}

weekinyear <- function(inputime){
  # 该函数 输入日期函数，返回该日期在该年内的第几周
  library(lubridate)
  timeformat <- as.POSIXct(inputime)
  if(is.POSIXct(timeformat)){
    return(lubridate::week(timeformat))  
  }else{
    print("输入的格式错误，清检查")
  }
}

weekinterval <- function(year,week){
  # 该函数，输入：年份、周数量
  # 输出： 该周的起始日期
  # 返回类型 list
  require(lubridate)
  date <- paste(year,"-01-01",sep = "")
  endtime <- as.Date(as.character(date))+week*7
  result_endtime <- as.Date(lubridate::ceiling_date(endtime,"week")- weeks(1))
  result_starttime <- result_endtime - days(6)
  result <- list(startdate=result_starttime,enddate=result_endtime)
  return(result)
}

weekfunsum <- function(inputDate){
  # 该函数输入：日期
  #输出 dataframe
  # data.frame(year=rs_year,month=rs_month,day=rs_day,weeknum=rs_weeknum,startdate=rs_startdate,endstart=rs_enddate)
  inputDate <- as.character(inputDate)
  inputDate <- as.Date(inputDate)
  rs_year <- lubridate::year(inputDate)
  rs_month <- lubridate::month(inputDate)
  rs_day <- lubridate::day(inputDate)
  rs_weeknum <- weekinyear(inputDate)
  week_interval <- weekinterval(rs_year,rs_weeknum)
  rs_startdate <-week_interval$startdate
  rs_enddate <- week_interval$enddate
  weekresult <- data.frame(year=rs_year,month=rs_month,day=rs_day,weeknum=rs_weeknum,startdate=rs_startdate,enddate=rs_enddate)
  return(weekresult)
}

connectSQL <- function(sqltype,confdata,curPath){
  sql_driver_path = paste(curPath,"../../shared_lib/jars",sep="/")
  if(sqltype=="mysql"){
    tryCatch({
      mysql_url = confdata[["mysql_url"]]
      mysql_uid = confdata[["mysql_uid"]]
      mysql_pwd = confdata[["mysql_pwd"]]
    },error=function(e) {
      stop("配置文件中 缺失:'mysql_url','mysql_uid','mysql_pwd'")
    })
    tryCatch({
      cp = c(list.files(sql_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
      jdbcDriver <-RJDBC::JDBC(driverClass="com.mysql.jdbc.Driver",classPath=cp)
      conn <- RJDBC::dbConnect(jdbcDriver, mysql_url,mysql_uid, mysql_pwd)
    },error=function(e){
      print(e)
    })
 
  }else if(sqltype=="oracle"){
    tryCatch({
      oracle_url = confdata[["oracle_url"]]
      oracle_uid = confdata[["oracle_uid"]]
      oracle_pwd = confdata[["oracle_pwd"]]
    },error=function(e){
      stop("配置文件中 缺失:'oracle_url','oracle_uid','oracle_pwd'")
    })
    tryCatch({
      cp = c(list.files(sql_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
      jdbcDriver <- RJDBC::JDBC(driverClass ="oracle.jdbc.driver.OracleDriver", classPath =cp) 
      conn <- RJDBC::dbConnect(jdbcDriver,oracle_url,oracle_uid,oracle_pwd)
    },error=function(e){
      print(e)
    })

  }else if(sqltype=="sqlserver"){
    tryCatch({
      sqlserver_url = confdata[["sqlserver_url"]]
      sqlserver_uid = confdata[["sqlserver_uid"]]
      sqlserver_pwd = confdata[["sqlserver_pwd"]]
      
    },error=function(e){
      stop("配置文件中 缺失:'sqlserver_url','sqlserver_uid','sqlserver_pwd'")
    })
    tryCatch({
      cp = c(list.files(sql_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
      jdbcDriver <- RJDBC::JDBC(driverClass = "com.microsoft.sqlserver.jdbc.SQLServerDriver", classPath =cp) 
      conn <- RJDBC::dbConnect(jdbcDriver,sqlserver_url,sqlserver_uid,sqlserver_pwd)
    },error=function(e){
      print(e)
    })
    
  }else if(sqltype=="hive"){
    tryCatch({
      hiveurlin = confdata[["hiveurlin"]]
      hivedriver = confdata[["hivedriver"]]
      hiveuser = confdata[["hiveuser"]]
      hivepassword = confdata[["hivepassword"]]
    },error=function(e){
      stop("配置文件中 缺失:'mysql_url','mysql_uid','mysql_pwd'")
    })
    tryCatch({
      cp = c(list.files(hivedriver, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
      drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
      conn = RJDBC::dbConnect(drv,hiveurlin,user=hiveuser, password=hivepassword)
    },error=function(e){
      
      print(e)
    })
   
  }else{
    stop("请输入正确的数据库类型名sqltype:'mysql','oracle','sqlserver','hive'")
  }
  return(conn)
}


## 坐标转换程序，由董良撰写并提交 2018-05-18 ##
FuncCoordConv <- function(var_conv1, lnglat=c('lng','lat'), from=1, to=5, AK="4SoaSvbIZ0HkLCrpxf32VHj7gvnxadQm"){
  if(!(from %in% c(1,2,3,4,5,6,7,8) | to %in% c(5,6) | class(var_conv1) == "data.frame")){
    stop("from: 1:GPS设备获取的角度坐标; 2：GPS获取的米制坐标、sogou地图所用坐标; 
                3：google地图、soso地图、aliyun地图、mapabc地图和amap地图所用坐标;
                4：3中列表地图坐标对应的米制坐标; 5：百度地图采用的经纬度坐标; 
                6：百度地图采用的米制坐标; 7：mapbar地图坐标; 8：51地图坐标
        to : 5：bd09ll(百度经纬度坐标); 6：bd09mc(百度米制经纬度坐标);")
  }
  library(RCurl)
  library(rjson)
  library(foreach)
  library(doParallel)
  library(plyr)
  library(dplyr)
  library(tidyr)
  
  #--- para ---#
  var_conv1 <- var_conv1 %>% unite_("xy",c(lnglat[1],lnglat[2]),sep=',') %>% as.data.frame
  var_conv1$group <- rep(1:ceiling(nrow(var_conv1)/100),each=100)[1:nrow(var_conv1)] # 百度api每次请求100条
  var_conv1$rownames <- 1:dim(var_conv1)[1] # 使用rownames对齐原始数据和api请求返回的数据
  xy <- 'xy'
  #--- para ---#
  
  #----- parallel -----#
  cores <- detectCores(logical = T)
  cl <- makeCluster(cores)
  registerDoParallel(cl, cores)
  #----- parallel -----#
  
  #--- application to all the data ---#
  ptm <- proc.time()
  
  baidu_coord <- ddply(var_conv1, .(group), .parallel = T, .paropts = list(.packages = c("RCurl","rjson")), .fun = function(x,xy,from,to,AK){
    if( nrow(x)<1 | ncol(x)<1 )stop("x must have more than one rows/cols")
    if(class(x)!="data.frame")stop("x must be a data.frame")
    if(!(xy %in% names(x)))stop("xy must a colname of x and is shaped as: 'lon,lat'")
    if(!is.numeric(from) | !is.numeric(to) | from > 8 | to < 5 | to > 6)stop("from: 1:GPS设备获取的角度坐标; 2：GPS获取的米制坐标、sogou地图所用坐标; 
                                                                             3：google地图、soso地图、aliyun地图、mapabc地图和amap地图所用坐标
                                                                             4：3中列表地图坐标对应的米制坐标; 5：百度地图采用的经纬度坐标; 
                                                                             6：百度地图采用的米制坐标; 7：mapbar地图坐标; 8：51地图坐标
                                                                             to:   5：bd09ll(百度经纬度坐标); 6：bd09mc(百度米制经纬度坐标);")
  
  strgeo <- paste(x[,xy], collapse = ";")
  
  #--- make a url ---#
  strurl <- paste0("http://api.map.baidu.com/geoconv/v1/?coords=", strgeo, "&from=", from, "&to=", to, "&output=json&ak=", AK)
  tryCatch(encodeurl <- URLencode(strurl), error=function(e){cat("ERROR : ", conditionMessage(e),"\n")})
  
  #--- convert coords ---#
  connect <- url(encodeurl) # 捕获链接对象
  temp_geo <- fromJSON(paste(readLines(connect, warn = F), collapse = ""))
  temp <- do.call("rbind", temp_geo$result)
  data <- paste(temp[,1], temp[,2], sep = ',')
  close(connect)
  
  return(data.frame(xy=data,rownames=x$rownames))
},xy=xy, from=from, to=to, AK=AK)

proc.time() - ptm

#----- parallel -----#
stopImplicitCluster()
stopCluster(cl)
#----- parallel -----#

# rlt<-plyr::join(var_conv1[, !(names(var_conv1) %in% 'group')], baidu_coord, by='rownames') %>% mutate(group=NULL,rownames=NULL) %>% 
#   separate(xy,c('lng','lat'),sep=',') %>% mutate(lng=as.numeric(lng),lat=as.numeric(lat)) %>% as.data.frame
rlt<-var_conv1[, !(names(var_conv1) %in% c('group','xy'))] %>% left_join(baidu_coord[, !(names(baidu_coord) %in% 'group')], by='rownames') %>% 
  mutate(group=NULL,rownames=NULL) %>% separate(xy,c('lng','lat'),sep=',') %>% mutate(lng=as.numeric(lng),lat=as.numeric(lat)) %>% as.data.frame
return(rlt)
}

##-- 判断事件点落在那个街道，由董良撰写并提交于2018-05-18 --##
FuncPtsinPoly <- function(points_data,lnglat=c('lng','lat'),des_polygon){
  #-- packages -------
  library(foreach)
  library(doParallel)
  
  if(!( sum(c('lng','lat') %in% names(points_data))==2 | class(points_data)=="data.frame") ){
    stop("inpute_data-points_data must be a data.frame and with cols named 'lng','lat',which indicate the lngtitude an latitude")
  }
  if(class(des_polygon)[1] != "SpatialPolygonsDataFrame"){
    stop("des_polygon must be a SpatialPolygonsDataFrame")
  }
  points_data$lng <- as.numeric(points_data$lng)
  points_data$lat <- as.numeric(points_data$lat)
  
  #-- make a data
  town_id  <- na.omit(data.frame(town_id=des_polygon$ID[!is.na(des_polygon$ID)],stringsAsFactors = F) )
  
  #----- parallel -----#
  cores <- detectCores(logical = T)
  cl <- makeCluster(cores)
  registerDoParallel(cl, cores)
  ptm <- proc.time()
  #----- parallel -----#
  
  points_data <- ddply(town_id, .(town_id), .parallel = T, .paropts = list(.packages = c("rgeos","sp")), 
                                         .fun = function(x,points_data,des_polygon){
                                           sub_polygon <- gUnaryUnion(des_polygon[des_polygon$ID %in% x,])
                                           ov <- sp::over(SpatialPoints(cbind(points_data$lng,points_data$lat), proj4string = CRS(proj4string(sub_polygon))), gUnaryUnion(sub_polygon))
                                           if(sum(!is.na(ov))>0){
                                             data <- points_data[!is.na(ov),]
                                             data$orgid <- rep(x$townid,nrow(data))
                                           }else{
                                             data <- data.frame()
                                           }
                                           return(data)
                                         },points_data=points_data,des_polygon=des_polygon)
  
  #----- parallel -----#
  proc.time() - ptm
  stopImplicitCluster()
  stopCluster(cl)
  #----- parallel -----#
  
  #-- rlt ----------------
  return(plyr::rename(points_data, c('town_id'='orgid')))
  
}
