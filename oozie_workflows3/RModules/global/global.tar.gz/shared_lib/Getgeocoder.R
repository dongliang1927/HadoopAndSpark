getURIs = function(uris, ..., multiHandle, .perform = TRUE)
{
  content = list()
  curls = list()
  for(i in uris) {
    curl = getCurlHandle()
    content[[i]] = basicTextGatherer()
    opts = curlOptions(URL = i,forbid.reuse=TRUE,writefunction = content[[i]]$update)
    curlSetOpt(.opts = opts, curl = curl)
    multiHandle = push(multiHandle, curl)
  }
  
  if(.perform) {
    complete(multiHandle)
    return(lapply(content, function(x) x$value()))
  } else {
    return(list(multiHandle = multiHandle, content = content))
  }
}

Getgeocoder <- function(X,AK){
  X1 <- X[!is.na(X$addr),]
  X2 <- levels(X1$addr)

  urls.temp<-NULL
  urls.location<-NULL
  tmp_geocoding_call_addr_temp <- seq(from=0.0, to=0.0, length=length(X2))
  tmp_geocoding_call_lng_temp <- seq(from=0.0, to=0.0, length=length(X2))
  tmp_geocoding_call_lat_temp <- seq(from=0.0, to=0.0, length=length(X2))
  for(band1 in 1:length(X2)) {
    location = X2[band1] 
    url <- paste("http://api.map.baidu.com/geocoder/v2/?ak=",AK,"&output=json&address=",location,"&city=","兰州市", sep = "")
    url_string <- URLencode(url)
    urls.location<-c(urls.location,location)
    urls.temp<-c(urls.temp,url_string)
    if((band1%%500==0)||(is.na(X2[band1+1]))){
      mHandle = getCurlMultiHandle()
      result<-getURIs(urls.temp, multiHandle = mHandle)
      rm(mHandle)
      gc()
      
      for(j in 1:length(result)){
	is_err <- FALSE
        temp_geo <- tryCatch({
          fromJSON(as.character(result[j]))
        },
        error = function(e) {
         # print("item error\n")
	  is_err <- TRUE
        })

	if(is_err == TRUE)
	  next
	else {
          if (is.null(temp_geo)){
            # print(paste("temp_geo is null :",location))
            tmp = data.frame(addr = urls.location[j],lng = 0,lat = 0)
          }else{
            if (!is.vector(temp_geo,mode = "list")){
              # print(paste("temp_geo is not list :",location))
              tmp = data.frame(addr = urls.location[j],lng = 0,lat = 0)
            }else{
              if (temp_geo$status == 0){
                temp_lat<-temp_geo$result$location$lat
                temp_lng<-temp_geo$result$location$lng
                tmp <- data.frame(addr = urls.location[j],lng=temp_lng,lat=temp_lat)
              }else{
                tmp = data.frame(addr = urls.location[j],lng = 0,lat = 0 )
                # print(paste("temp_geo.status is not 0 :",location))
              }
            }
          }
	}

        tmp_geocoding_call_addr_temp[band1+1-j] = as.character(tmp$addr[1])
        tmp_geocoding_call_lng_temp[band1+1-j] = as.character(tmp$lng[1])
        tmp_geocoding_call_lat_temp[band1+1-j] = as.character(tmp$lat[1])
      }
      urls.temp<-NULL
      urls.location<-NULL
    }
  }
  tmp_geocoding_call=data.frame(addr=tmp_geocoding_call_addr_temp,lng=tmp_geocoding_call_lng_temp,lat=tmp_geocoding_call_lat_temp)
  return(tmp_geocoding_call)
}
