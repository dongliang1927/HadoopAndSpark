#!/bin/bash
hive -e "CREATE DATABASE IF NOT EXISTS $1; DROP TABLE IF EXISTS $1.$3;
CREATE  TABLE $1.$3(rownames int,id string,orgid string,name string,coord string,labpt string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:id,cf:orgid,cf:name,cf:coord,cf:labpt\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$3\");

DROP TABLE IF EXISTS $1.$4;
CREATE  TABLE $1.$4(rownames int,id string,orgid string,name string,coord string,labpt string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:id,cf:orgid,cf:name,cf:coord,cf:labpt\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$4\")"



impala-shell -i $2 -q "INVALIDATE METADATA" 
