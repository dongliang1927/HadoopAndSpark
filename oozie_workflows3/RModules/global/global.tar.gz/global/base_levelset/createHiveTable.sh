#!/bin/bash 
hive -e "CREATE DATABASE IF NOT EXISTS $1; DROP TABLE IF EXISTS $1.$2;
CREATE  TABLE $1.$2(rownames int,id string,coding int,parentid string,codingname string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:id,cf:coding,cf:parentid,cf:codingname\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$2\")"

impala-shell -i $3 -q "INVALIDATE METADATA" 

