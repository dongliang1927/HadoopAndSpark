library(RODBC)
library(rjson)
library(rgdal)
library(plyr)

#老陶模式
argv <- commandArgs(TRUE)
Cur_Path = as.character(argv[1])
# Cur_Path <- "/data/home/wangchangsheng/datamining/data-mining/projects/data-mining-cloud/src/main/RModules/global/base_levelset"
json_path <- paste(Cur_Path,"../../shared_lib/getconfig.R",sep = "/")
source(json_path)
json_data <- getconfig(Cur_Path)
#R调试模式
# dir = c("/home/wangjiaqiang/RWorks_Wjq")
# dir2 = paste(dir, 'Pre_Work/2levelset', sep = '/')
# json_path = paste(dir2, "config.json", sep = "/")

accord_coding = data.frame(codingname=c("网格/组","社区/村","街道/乡镇","区/县","地级市","省","中央"),coding=c(7,6,5,4,3,2,1))
json_name = names(json_data)

impalaurl <- as.character(json_data[["impalaurl"]])
hive_driver_path <- as.character(json_data[["hivedriver"]])
hive_name <- as.character(json_data[["hiveuser"]])
hive_password <- as.character(json_data[["hivepassword"]])
hive_url_in <- as.character(json_data[["hiveurlin"]])
hive_url_out <- as.character(json_data[["hiveurlout"]])
hivedatabase <- unlist(strsplit(hive_url_in,'/'))
hivedatabase <- hivedatabase[length(hivedatabase)]

dsn_name = as.character(json_data[which(json_name == "dsn")])
uid_name = as.character(json_data[which(json_name == "uid")])
pwd_name = as.character(json_data[which(json_name == "pwd")])

tablename_level = as.character(json_data[which(json_name == "out_table_levelset")])
tablename_baseorg = as.character(json_data[which(json_name=="in_table_baseorg")])
shapefilepath = as.character(json_data[which(json_name=="shapepath")])
sub_path = as.character(json_data[which(json_name=="sub_path")])
shapename = as.character(json_data[which(json_name=="shapename")])

Coding_Building = as.numeric(json_data[which(json_name=="Coding_Buid")])
Coding_Grid = as.numeric(json_data[which(json_name=="Coding_Grid")])

cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url_in,user=hive_name, password=hive_password)
base_org <- RJDBC::dbGetQuery(hiveconnection,paste("select id,path from ",tablename_baseorg,sep=""))
RJDBC::dbDisconnect(hiveconnection)
# pep <-  odbcConnect(dsn_name,  uid = uid_name,  pwd = pwd_name,   believeNRows = FALSE,   DBMSencoding = "utf8" )
# base_org <- sqlQuery(pep,paste("select * from",tablename_baseorg))
# close(pep)  # 关闭连接

#读取其他Polygons信息
# shapefilepath = paste(Cur_Path, shapefilepath, sep="/")
# build_path = paste(shapefilepath,sub_path,sep = "/")
# thisshape = readOGR(build_path, shapename,encoding = "UTF-8")


pointnum=gregexpr("[.]", base_org$path)
tmp = data.frame(id=base_org$id,num=sapply(pointnum, length))
#添加parentid
tmp$parentid=0
for (band in 1:nrow(tmp)) {
  cur_index = tmp$num[band]
  if(cur_index>1){
    startpos = pointnum[[band]][cur_index-1] +1 
    endpos   = pointnum[[band]][cur_index] -1
    tmp$parentid[band] = substr(base_org$path[band],startpos,endpos)
  }else{
    startpos = 1 
    endpos   = pointnum[[band]][cur_index] -1
    tmp$parentid[band] = substr(base_org$path[band],startpos,endpos)
  }
}

tmp2 = table(tmp$num)
tmp2 = data.frame(tmp2)
names(tmp2) = c("coding","num")
tmp2$coding = as.numeric(as.character(tmp2$coding))

diff = Coding_Grid - tmp2$coding[which(tmp2$num==max(tmp2$num))]

tmp$num = tmp$num + diff
names(tmp) = c("id","coding","parentid")
boundary_level = join(tmp,accord_coding,by="coding",type="left")
boundary_level2 = boundary_level[!duplicated(boundary_level$id),]

pep <-  odbcConnect(dsn_name,  uid = uid_name,  pwd = pwd_name,   believeNRows = FALSE,   DBMSencoding = "utf8" )

odbcSetAutoCommit(pep, FALSE)
existtable = sqlTables(pep)
if(length(which(existtable$TABLE_NAME==tablename_level))>0){
  sqlDrop(pep,tablename_level)
}
sqlSave(pep , boundary_level2, tablename = tablename_level,append = TRUE)#table_name
odbcEndTran(pep, TRUE)
close(pep)



cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url_out,user=hive_name, password=hive_password)
# ***************************out_table_one************************************************
cmd <- paste(Cur_Path,"/createHiveTable.sh ",hivedatabase," ",tablename_level," ",impalaurl,sep="")
system(cmd)

result_dataframe <- boundary_level2
result_database <- tablename_level

result_dataframe$rownames <- 1:nrow(result_dataframe)
intable <- result_dataframe
HiveInsertFunc(hiveconnection,intable,result_database,impalaurl,step=10000)

RJDBC::dbDisconnect(hiveconnection)
# ***************************************************************************









