#!/bin/bash

Rscript $(cd `dirname $0`;pwd)/levelset.R $(cd `dirname $0`;pwd) &