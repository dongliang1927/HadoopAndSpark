该程序由王加强完成
1.概述：本程序处理原始的shape文件Polygons，将Polygons的构成字符串的形式保存在数据表中
  runtype=1时为R调用模式，按照原来R的设定运行，为其他值时为老陶命令行调用模式
2.输入参数：json文件路径（路径需要使用反斜杠）
3.依赖的文件：网格shape文件boundary_Trans，楼盘shape文件D_Building_Trans
4.依赖的表格：base_levelset
5.以来的包：plyr、RODBC、rjson
6.输出
     该程序输出为Mysql数据库表，程序输出2个表格，各表格介绍如下。	
     （1）Polygons，该表格由id，name，coding,center_lng,center_lat,poly_pts,orgid,orgname和path,分别代表当前Polygons的id，名称，级别编码，中心点lng坐标，中心点lat坐标，Polygons字符串，所属网格id(楼盘)/当前行政区域id（网格、社区等其他级别Polygons），隶属关系
      （2）multi_polyid，包含多个polygons闭环的ID，如某个网格包含多个Polygons闭环。

