##生成java用于显示的各种Polygons
rm(list = ls())
graphics.off()

library(plyr)
library(RODBC)
library(rjson)
library(rgdal)

# 
argv <- commandArgs(TRUE)
Cur_Path = as.character(argv[1])
# Cur_Path <- "/data/home/wangchangsheng/sadan/trunk/backend-schedule-modules/src/main/RModules/global/base_polygons_gen"
json_path <- paste(Cur_Path,"../../shared_lib/getconfig.R",sep = "/")
source(json_path)
json_data <- getconfig(Cur_Path)
# dir = c("/home/wangjiaqiang/RWorks_Wjq")
# dir2 = paste(dir, 'Pre_Work/3Polygons', sep = '/')
# json_path = paste("/home/wangjiaqiang/SVN/data-mining/projects/data-mining-mvc/src/main/webapp/RModules/global/base_polygons_gen", "config.json", sep = "/")

json_name = names(json_data)

runtype = as.numeric(json_data[which(json_name == "runtype")])#runtype=1为R调用模式，否则为Java命令行调用模式

impalaurl <- as.character(json_data[["impalaurl"]])
hive_driver_path <- as.character(json_data[["hivedriver"]])
hive_name <- as.character(json_data[["hiveuser"]])
hive_password <- as.character(json_data[["hivepassword"]])
hive_url_in <- as.character(json_data[["hiveurlin"]])
hive_url_out <- as.character(json_data[["hiveurlout"]])
hivedatabase <- unlist(strsplit(hive_url_in,'/'))
hivedatabase <- hivedatabase[length(hivedatabase)]

dsn_name = as.character(json_data[which(json_name == "dsn")])
uid_name = as.character(json_data[which(json_name == "uid")])
pwd_name = as.character(json_data[which(json_name == "pwd")])
table_name = as.character(json_data[which(json_name == "out_table_polygons")])
#tablename_level= as.character(json_data[which(json_name == "in_table_levelset")])
min_lng = as.numeric(json_data[which(json_name == "min_lng")])
max_lng = as.numeric(json_data[which(json_name == "max_lng")])
min_lat = as.numeric(json_data[which(json_name == "min_lat")])
max_lat = as.numeric(json_data[which(json_name == "max_lat")])
levelset = as.character(json_data[which(json_name=="in_table_base_levelset")])

cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url_in,user=hive_name, password=hive_password)

levelset <- RJDBC::dbGetQuery(hiveconnection,paste("select id,coding from ",levelset, sep=""))

RJDBC::dbDisconnect(hiveconnection)


# pep <- odbcConnect(dsn_name, uid = uid_name, pwd = pwd_name, believeNRows = FALSE, DBMSencoding = "utf8")
# levelset<-sqlFetch(pep,levelset)
# close(pep)


if(runtype==1){
  shapefilepath = as.character(json_data[which(json_name=="shapepath_R")]) #R调试模式
}else{
  shapefilepath = as.character(json_data[which(json_name=="shapepath_J")]) #老陶模式
}

sub_path = as.character(json_data[which(json_name=="sub_path")])
shapename = as.character(json_data[which(json_name=="shapename")])
sub_path_grid = as.character(json_data[which(json_name=="sub_path_grid")])
shapename_grid = as.character(json_data[which(json_name=="shapename_grid")])

Multi_PolyID = as.character(json_data[which(json_name == "out_table_multi_polyid")])
output_format = as.numeric(json_data[which(json_name == "output_format")])
##大数据系统编码，楼盘为8，网格7，。。。。。。中央1
Coding_Buid  =  as.numeric(json_data[which(json_name=="Coding_Buid")])

#读取楼盘信息
if(runtype==1){
  buildpath = paste(shapefilepath,sub_path,sep = "/")
  D_Building = readOGR(buildpath, shapename,encoding = "UTF-8")
  
}else{
  shapefilepath_building = paste(Cur_Path, shapefilepath, sep="/")
  build_path = paste(shapefilepath_building,sub_path,sep = "/")
  D_Building = readOGR(build_path, shapename,encoding = "UTF-8")
}

nfiles    = length(D_Building@polygons)
xx = numeric(0)
yy = numeric(0)
#bound = c(nfiles)
bound = character(0)
for (band in 1:nfiles) {
  t12 = slot(D_Building@polygons[[band]], "Polygons")
  
  for (tt in 1:length(t12)) {
    t22 = slot(t12[[tt]], "coords")
    t_x = as.character(t22[, 1]) #第一列，x
    t_y = as.character(t22[, 2]) #第一列，x
    tmp = paste(t_x, t_y, sep = ",", collapse = ";")
    bound[band] = ifelse(is.na(bound[band]), tmp, paste(bound[band], tmp, sep = "#"))
  }
  xx[band] = slot(slot(D_Building@polygons[[band]], "Polygons")[[1]], "labpt")[1]
  yy[band] = slot(slot(D_Building@polygons[[band]], "Polygons")[[1]], "labpt")[2]
}
except_index = which(xx<min_lng | xx>max_lng | yy<min_lat | yy>max_lat)
xx[except_index] = 0 
yy[except_index] = 0
#Building_Data = data.frame(id=D_Building@data$ID,name=D_Building@data$NAME,center_lng=xx,center_lat=yy,poly_pts = bound,orgid=D_Building@data$ORGID,orgname=D_Building@data$ORGNAME,path=D_Building@data$ORGPATH)
Building_Data = data.frame(id=D_Building@data$ID,name=D_Building@data$NAME,center_lng=xx,center_lat=yy,poly_pts = bound,orgid=D_Building@data$ORGID,orgname=D_Building@data$ORGNAME,path=D_Building@data$ORGPATH)



#读取其他Polygons信息
if(runtype==1){
  boundarypath = paste(shapefilepath,sub_path_grid,sep = "/")
  Dongying_Boundary = readOGR(boundarypath, shapename_grid,encoding = "UTF-8")  
}else{
  shapefilepath_boundary = paste(Cur_Path, shapefilepath, sep="/")
  build_path = paste(shapefilepath_boundary,sub_path_grid,sep = "/")
  Dongying_Boundary = readOGR(build_path, shapename_grid,encoding = "UTF-8")
}
# boundarypath = paste(shapefilepath,"boundary",sep = "/")
# Dongying_Boundary = readOGR(boundarypath, "boundary3",encoding = "UTF-8")

nfiles    = length(Dongying_Boundary@polygons)
xx = numeric(0)
yy = numeric(0)
#bound = c(nfiles)
bound = character(0)
for(band in 1:nfiles)
{
  t12 = slot(Dongying_Boundary@polygons[[band]], "Polygons")
  
  for (tt in 1:length(t12)) {
    t22 = slot(t12[[tt]], "coords")
    t_x = as.character(t22[, 1]) #第一列，x
    t_y = as.character(t22[, 2]) #第一列，x
    tmp = paste(t_x, t_y, sep = ",", collapse = ";")
    bound[band] = ifelse(is.na(bound[band]), tmp, paste(bound[band], tmp, sep = "#"))
  }
  xx[band] = slot(slot(Dongying_Boundary@polygons[[band]],"Polygons")[[1]],"labpt")[1]
  yy[band] = slot(slot(Dongying_Boundary@polygons[[band]],"Polygons")[[1]],"labpt")[2]  
}
except_index = which(xx<min_lng | xx>max_lng | yy<min_lat | yy>max_lat)
xx[except_index] = 0 
yy[except_index] = 0
Boundary_Data = data.frame(id=Dongying_Boundary@data$ID,name=Dongying_Boundary@data$ORGNAME,center_lng=xx,center_lat=yy,poly_pts = bound,orgid=Dongying_Boundary@data$ID,orgname=Dongying_Boundary@data$ORGNAME,path=Dongying_Boundary@data$PATH)

Poly_Entirety = rbind(Building_Data,Boundary_Data)

##############################################################利用楼盘shp文件弥补网格shp文件中，坐标确实情况
coding = data.frame(id = levelset$id, coding = levelset$coding)
polygons_1 = join(Poly_Entirety, coding, by = "id")

modify_polygons = subset(polygons_1,polygons_1$coding >= 3 & polygons_1$coding < 8 & polygons_1$center_lng == 0)

for(i in 1:nrow(modify_polygons)){
  Base_Index = grep(modify_polygons$path[i],polygons_1$path,value=F)
  Base_ID = polygons_1[Base_Index,]
  Base_ID = Base_ID[-which(Base_ID$center_lng == 0),]
  if(nrow(Base_ID) > 0){
    x <- mean(Base_ID$center_lng)
    y <- mean(Base_ID$center_lat)
    modify_polygons$center_lng[i] <- x
    modify_polygons$center_lat[i] <- y
  }
  polygons_1[which(modify_polygons$id[i] == polygons_1$id),] <- modify_polygons[i,]
}

polygons_1$coding[is.na(polygons_1$coding)] <-  8
Poly_Entirety = polygons_1[c(1:8)]
##############################################################
# #下面计算一个polygons含有多个环的情况
# nfiles    = length(Dongying_Boundary@polygons)
# bound2 = data.frame(id=0,count=0)
# cur_index = 1
# for(band in 1:nfiles)
# {
#   t12 = slot(Dongying_Boundary@polygons[[band]], "Polygons")
#   if(length(t12)>1){
#     tmp = data.frame(id=Dongying_Boundary@data$ID[band],count=1)
#     bound2=rbind(bound2,tmp)
#   }
# }
# #读取级别设置表
# pep <-  odbcConnect(dsn_name,  uid = uid_name,  pwd = pwd_name,   believeNRows = FALSE,   DBMSencoding = "utf8" )
# odbcSetAutoCommit(pep, FALSE)
# if(output_format==1){
#   write.csv(Poly_Entirety,file = paste(table_name,".csv",sep = ""),row.names = FALSE,fileEncoding = "UTF-8")
#   write.csv(bound2,file = paste(Multi_PolyID,".csv",sep = ""),row.names = FALSE)
#   
# }else{
#   existtable = sqlTables(pep)
#   if(length(which(existtable$TABLE_NAME==table_name))>0){
#     sqlDrop(pep,table_name)
#   }
#   if(length(which(existtable$TABLE_NAME==Multi_PolyID))>0){
#     sqlDrop(pep,Multi_PolyID)
#   }
#   
#   #sqlDrop(pep,table_name)
#   
#   sqlSave(pep , Poly_Entirety, tablename = table_name,varTypes=c(poly_pts="varchar(65533)"),append = TRUE)#table_name
#   sqlSave(pep , bound2, tablename = Multi_PolyID,append = TRUE)#table_name
#   odbcEndTran(pep, TRUE)
# }
# close(pep) 
# 
# # pep <- odbcConnect(dsn_name, uid = uid_name, pwd = pwd_name, believeNRows = FALSE, DBMSencoding = "utf8")
# # levelset<-sqlFetch(pep,"rlt_base_polygons")
# # close(pep)


cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url_out,user=hive_name, password=hive_password)
# ***************************out_table_one************************************************
inserHiveFunctionV2(hiveconnection, hivedatabase, impalaurl, step = 10000,Poly_Entirety, table_name)

# cmd <- paste(Cur_Path,"/createHiveTable.sh ",hivedatabase," ",table_name," ",impalaurl,sep="")
# system(cmd)
# 
# result_dataframe <- Poly_Entirety
# result_database <- table_name
# 
# result_dataframe$rownames <- 1:nrow(result_dataframe)
# 
# intable <- result_dataframe
# 
# HiveInsertFunc(hiveconnection,intable,result_database,impalaurl,step=10000)

RJDBC::dbDisconnect(hiveconnection)
# ***************************************************************************

