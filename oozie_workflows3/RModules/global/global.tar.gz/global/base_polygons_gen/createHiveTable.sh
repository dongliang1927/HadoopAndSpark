#!/bin/bash 
hive -e "CREATE DATABASE IF NOT EXISTS $1; DROP TABLE IF EXISTS $1.$3;
CREATE  TABLE $1.$3(rownames int,id string,name string,center_lng double,center_lat double,poly_pts string,orgid string,orgname string,path string)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:id,cf:name,cf:center_lng,cf:center_lat,cf:poly_pts,cf:orgid,cf:orgname,cf:path\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$3\")"

impala-shell -i $2 -q "INVALIDATE METADATA" 

