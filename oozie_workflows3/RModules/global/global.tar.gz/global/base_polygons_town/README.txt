该程序由王长生完成
1.概述：本程序处理原始的shape文件Polygons，将Polygons的构成字符串的形式保存在数据表中
  
2.输入参数：json文件路径（路径需要使用反斜杠）
3.依赖的文件：
4.依赖的表格：
5.以来的包：plyr、RODBC、rjson、rgdal
6.输出


