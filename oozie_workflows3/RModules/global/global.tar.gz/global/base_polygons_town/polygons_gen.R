# -------------------- 该程序实现，将购于空间公司的shp文件， 读入数据库（WGS84），方便后续操作。----------------------------

#	        该程序读取兰州市区县的shp文件（*/RMes/shared_data/lanzhou_town/LanZhou_city_ID.shp），将区县ID，维拓自定义orgid，轮廓信息，中心点坐标（WGS84），区县名称写入数据库。
#	为调用*/archived-projects/baidugeoconvertor/进行坐标转会。
#

rm(list = ls())
graphics.off()

library(plyr)
library(RODBC)
library(rgdal)
library(dplyr)

argv <- commandArgs(TRUE)
Cur_Path = as.character(argv[1])
# Cur_Path <- "/data/home/wangchangsheng/sadan/trunk/backend-schedule-modules/src/main/RModules/global/base_polygons_town"
json_path <- paste(Cur_Path,"../../shared_lib/getconfig.R",sep = "/")
source(json_path)
json_data <- getconfig(Cur_Path)

impalaurl <- as.character(json_data[["impalaurl"]])
hive_driver_path <- as.character(json_data[["hivedriver"]])
hive_name <- as.character(json_data[["hiveuser"]])
hive_password <- as.character(json_data[["hivepassword"]])
hive_url_in <- as.character(json_data[["hiveurlin"]])
hive_url_out <- as.character(json_data[["hiveurlout"]])
hivedatabase <- unlist(strsplit(hive_url_in,'/'))
hivedatabase <- hivedatabase[length(hivedatabase)]


dsn_name <- json_data[["dsn"]]
uid_name <- json_data[["uid"]]
pwd_name <- json_data[["pwd"]]
shp_path <- json_data[["shp_path"]]
shp_name <- json_data[["shp_name"]]

# in_base_org <- json_data[["in_table_base_org"]]
out_table_polygons_bd <- json_data[["out_table_polygons_bd"]]
out_changping_polygons <- json_data[["out_table_polygons"]]

# pep <-  odbcConnect(dsn_name,  uid = uid_name,  pwd = pwd_name,   believeNRows = FALSE,   DBMSencoding = "utf8" )
# # base_org <- sqlQuery(pep,paste("select ID as orgid,PARENTID "))
# close(pep)
shp_path_all <- paste(Cur_Path,shp_path,sep="/")
yy <- readOGR(shp_path_all, shp_name)

## 坐标转换程序，由董良撰写并提交 2018-05-18 ##
FuncCoordConv <- function(var_conv1, lnglat=c('lng','lat'), from=1, to=5, AK="kmA8NOvMeosIFWmNlLREnt2i"){
  if(!(from %in% c(1,2,3,4,5,6,7,8) | to %in% c(5,6) | class(var_conv1) == "data.frame")){
    stop("from: 1:GPS设备获取的角度坐标; 2：GPS获取的米制坐标、sogou地图所用坐标; 
         3：google地图、soso地图、aliyun地图、mapabc地图和amap地图所用坐标;
         4：3中列表地图坐标对应的米制坐标; 5：百度地图采用的经纬度坐标; 
         6：百度地图采用的米制坐标; 7：mapbar地图坐标; 8：51地图坐标
         to : 5：bd09ll(百度经纬度坐标); 6：bd09mc(百度米制经纬度坐标);")
  }
  library(RCurl)
  library(rjson)
  library(foreach)
  library(doParallel)
  library(plyr)
  library(dplyr)
  library(tidyr)
  
  #--- para ---#
  var_conv1 <- var_conv1 %>% unite_("xy",c(lnglat[1],lnglat[2]),sep=',') %>% as.data.frame
  var_conv1$group <- rep(1:ceiling(nrow(var_conv1)/100),each=100)[1:nrow(var_conv1)] # 百度api每次请求100条
  var_conv1$rownames <- 1:dim(var_conv1)[1] # 使用rownames对齐原始数据和api请求返回的数据
  xy <- 'xy'
  #--- para ---#
  
  #----- parallel -----#
  cores <- detectCores(logical = T)
  cl <- makeCluster(cores)
  registerDoParallel(cl, cores)
  #----- parallel -----#
  
  #--- application to all the data ---#
  ptm <- proc.time()
  
  baidu_coord <- ddply(var_conv1, .(group), .parallel = T, .paropts = list(.packages = c("RCurl","rjson")), .fun = function(x,xy,from,to,AK){
    if( nrow(x)<1 | ncol(x)<1 )stop("x must have more than one rows/cols")
    if(class(x)!="data.frame")stop("x must be a data.frame")
    if(!(xy %in% names(x)))stop("xy must a colname of x and is shaped as: 'lon,lat'")
    if(!is.numeric(from) | !is.numeric(to) | from > 8 | to < 5 | to > 6)stop("from: 1:GPS设备获取的角度坐标; 2：GPS获取的米制坐标、sogou地图所用坐标; 
                                                                             3：google地图、soso地图、aliyun地图、mapabc地图和amap地图所用坐标
                                                                             4：3中列表地图坐标对应的米制坐标; 5：百度地图采用的经纬度坐标; 
                                                                             6：百度地图采用的米制坐标; 7：mapbar地图坐标; 8：51地图坐标
                                                                             to:   5：bd09ll(百度经纬度坐标); 6：bd09mc(百度米制经纬度坐标);")
    
    strgeo <- paste(x[,xy], collapse = ";")
    
    #--- make a url ---#
    strurl <- paste0("http://api.map.baidu.com/geoconv/v1/?coords=", strgeo, "&from=", from, "&to=", to, "&output=json&ak=", AK)
    tryCatch(encodeurl <- URLencode(strurl), error=function(e){cat("ERROR : ", conditionMessage(e),"\n")})
    
    #--- convert coords ---#
    connect <- url(encodeurl) # 捕获链接对象
    temp_geo <- fromJSON(paste(readLines(connect, warn = F), collapse = ""))
    temp <- do.call("rbind", temp_geo$result)
    data <- paste(temp[,1], temp[,2], sep = ',')
    close(connect)
    
    return(data.frame(xy=data,rownames=x$rownames))
  },xy=xy, from=from, to=to, AK=AK)
  
  proc.time() - ptm
  
  #----- parallel -----#
  stopImplicitCluster()
  stopCluster(cl)
  #----- parallel -----#
  
  # rlt<-plyr::join(var_conv1[, !(names(var_conv1) %in% 'group')], baidu_coord, by='rownames') %>% mutate(group=NULL,rownames=NULL) %>% 
  #   separate(xy,c('lng','lat'),sep=',') %>% mutate(lng=as.numeric(lng),lat=as.numeric(lat)) %>% as.data.frame
  middle_data <- as.data.frame(var_conv1[, !(names(var_conv1) %in% c('group','xy'))])
  names(middle_data) <- "rownames"
  rlt<-middle_data %>% left_join(baidu_coord[, !(names(baidu_coord) %in% 'group')], by='rownames') %>% 
    mutate(group=NULL,rownames=NULL) %>% separate(xy,c('lng','lat'),sep=',') %>% mutate(lng=as.numeric(lng),lat=as.numeric(lat)) %>% as.data.frame
  return(rlt)
  }
###############

changping_polygons_bd <- data.frame()
changping_polygons <- data.frame()
for(each_data in 1:length(yy@data$OBJECTID)){
  object.id <- yy@data$townid[each_data]
  object.name <- yy@data$townname[each_data]
  object.orgid <- yy@data$ID[each_data]
  # coords <- slot(yy@polygons[[each_data]],"Polygons")[[1]]
  sum_coords <- slot(yy@polygons[[each_data]],"Polygons")
  
  # muilti polygons to merg
  
  for(each_coord in 1:length(sum_coords)){
    each_object_coord <- sum_coords[[each_coord]]@coords
    # ------- 此处实现调用百度api进行坐标转化 ----------
    # ------ down - 此处实现调用百度api进行坐标转化 ----------
    # each_object_coord_bd <- as.data.frame(each_object_coord)
    temp_data <- as.data.frame(each_object_coord) %>% rename(lng='V1',lat='V2') %>% mutate(lng=as.numeric(lng),lat=as.numeric(lat))
    each_object_coord_bd <- FuncCoordConv(temp_data,lnglat = c("lng","lat"))
    
    sum_coords_bd <- data.frame(lng=sum_coords[[each_coord]]@labpt[1],lat=sum_coords[[each_coord]]@labpt[2])
    sum_coords_bd <- FuncCoordConv(sum_coords_bd,lnglat = c("lng","lat"))
    each_object_labpt_bd <- paste(sum_coords_bd[1,1],sum_coords_bd[1,2],sep=",")
    
    each_str_object_coord_bd <- paste(each_object_coord_bd[,1],each_object_coord_bd[,2],sep = ",",collapse = ";")
    each_polygons_bd <- data.frame(id=object.id,orgid = object.orgid,name=object.name,coord=each_str_object_coord_bd,labpt = each_object_labpt_bd)
    changping_polygons_bd <- rbind(changping_polygons_bd,each_polygons_bd)
    
    # ------ up - 此处实现调用百度api进行坐标转化 ----------
    # ------- ----------
    # object.coord <- coords@coords
    each_object_labpt <- paste(sum_coords[[each_coord]]@labpt[1],sum_coords[[each_coord]]@labpt[2],sep=",")
    
    each_str_object_coord <- paste(each_object_coord[,1],each_object_coord[,2],sep = ",",collapse = ";")
    each_polygons <- data.frame(id=object.id,orgid = object.orgid,name=object.name,labpt = each_object_labpt,coord=each_str_object_coord)
    changping_polygons <- rbind(changping_polygons,each_polygons)
  }
}

changping_polygons$coord <- as.character(changping_polygons$coord)
changping_polygons_bd$coord <- as.character(changping_polygons_bd$coord)


cp = c(list.files(hive_driver_path, pattern = "[.]jar", full.names=TRUE, recursive=TRUE),recursive=TRUE)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver",classPath = cp)
hiveconnection = RJDBC::dbConnect(drv,hive_url_out,user=hive_name, password=hive_password)
# ***************************out_table_one************************************************

inserHiveFunctionV2(hiveconnection,hivedatabase,impalaurl,step=10000,changping_polygons,out_changping_polygons,changping_polygons_bd,out_table_polygons_bd)
RJDBC::dbDisconnect(hiveconnection)

