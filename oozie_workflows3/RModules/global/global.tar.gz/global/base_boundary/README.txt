1.概述
本程序由耿莉媛编写，功能为:
1.生成兰州市边界数据。

2.输入命令行参数：无

3.依赖的Ｒ包：RODBC、rjson、maptools

4．依赖的Ｒ分析模块：无

5．输入
        由百度地图获取的兰州市边界文件：Boundary.txt
　        	
6.输出
     该程序输出为Mysql数据库表，分别为：
     out_table_base_boundary表格，为兰州市边界数据表，该表由 "lng", "lat"  字段组成,分别为兰州市边界纬度坐标，经度坐标；
        

7.config.json
        本程序使用读取缺省配置文件config.json的方式进行输入，配置文件属性说明如下：
        dsn：ODBC数据源名称，
        uid:数据库用户名，
        pwd：数据库登陆密码，  
     
        out_table_base_boundary：输出表格的名称，在此表格中有兰州市边界纬度坐标，经度坐标。
       
       
        
	

