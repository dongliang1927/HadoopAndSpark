#!/bin/bash 
hive -e "CREATE DATABASE IF NOT EXISTS $1; DROP TABLE IF EXISTS $1.$3;
CREATE  TABLE $1.$3(rownames int,lng double,lat double)
STORED BY \"org.apache.hadoop.hive.hbase.HBaseStorageHandler\" 
WITH SERDEPROPERTIES(\"hbase.columns.mapping\"=\":key,cf:lng,cf:lat\") 
TBLPROPERTIES(\"hbase.table.name\" = \"$1:$3\")"


impala-shell -i $2 -q "INVALIDATE METADATA" 

