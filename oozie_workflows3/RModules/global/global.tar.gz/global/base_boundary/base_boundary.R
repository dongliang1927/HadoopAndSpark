#本程序由耿莉媛编写。程序功能：1.生成兰州市边界数据。2.从数据库读取企业信息，获取企业的经纬度并优化。
rm(list = ls())
#设置科学计数法位数，避免id等数值以科学计数法表示。
options(scipen = 20)

library(RODBC)
library(rjson)
library(maptools)

argv <- commandArgs(TRUE)
Cur_Path = as.character(argv[1])
# Cur_Path <- "/data/home/wangchangsheng/sadan/trunk/backend-schedule-modules/src/main/RModules/global/base_boundary"
json_path <- paste(Cur_Path,"../../shared_lib/getconfig.R",sep = "/")
source(json_path)
json_data <- getconfig(Cur_Path)
json_name = names(json_data)

impalaurl <- as.character(json_data[["impalaurl"]])
hive_driver_path <- as.character(json_data[["hivedriver"]])
hive_name <- as.character(json_data[["hiveuser"]])
hive_password <- as.character(json_data[["hivepassword"]])
hive_url_in <- as.character(json_data[["hiveurlin"]])
hive_url_out <- as.character(json_data[["hiveurlout"]])
hivedatabase <- unlist(strsplit(hive_url_in,'/'))
hivedatabase <- hivedatabase[length(hivedatabase)]

dsn_name= as.character(json_data[which(json_name=="dsn")])
uid_name = as.character(json_data[which(json_name=="uid")])
pwd_name = as.character(json_data[which(json_name=="pwd")])

path_boundary = Cur_Path 
out_table_base_boundary = as.character(json_data[which(json_name=="out_table_base_boundary")])

path_boundary = paste(path_boundary,"boundary.txt",sep = "/")
Boundary = read.table(path_boundary,sep = ";")

#读入百度地图提供的区域轮廓线
boundary = data.frame()
for(band in 1:length(Boundary))
{
  tt1 = unlist(strsplit(as.character(Boundary[1,band]),split= ","))
  tmp = data.frame(lng=as.numeric(tt1[1]),lat = as.numeric(tt1[2]))
  boundary = rbind(boundary,tmp)
}

# pep <- odbcConnect(dsn_name, uid=uid_name, pwd=pwd_name,believeNRows=FALSE,DBMSencoding="utf8")
# existtable = sqlTables(pep)
# odbcSetAutoCommit(pep, FALSE)
# if(length(which(existtable$TABLE_NAME==out_table_base_boundary))>0){
#   sqlDrop(pep,out_table_base_boundary)
# }
# 
# #保存到数据库
# sqlSave(pep,boundary,tablename = out_table_base_boundary,append = TRUE)
# odbcEndTran(pep, TRUE)
# close(pep)  # 关闭连接

cp <- c(list.files(hive_driver_path, pattern = "[.]jar", full.names = T, recursive = T), recursive = T)
drv <- RJDBC::JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver", classPath = cp)
hiveconnection <- RJDBC::dbConnect(drv, hive_url_out, user = hive_name, password = hive_password)
# ***************************out_table_one************************************************


inserHiveFunctionV2(hiveconnection, hivedatabase, impalaurl, step = 10000,boundary,out_table_base_boundary)
# 
# cmd <- paste(Cur_Path,"/createHiveTable.sh ",hivedatabase," ",out_table_base_boundary," ",impalaurl,sep="")
# system(cmd)
# 
# result_dataframe <- boundary
# result_database <- out_table_base_boundary
# 
# result_dataframe$rownames <- 1:nrow(result_dataframe)
# 
# intable <- result_dataframe
# 
# HiveInsertFunc(hiveconnection,intable,result_database,impalaurl,step=10000)

RJDBC::dbDisconnect(hiveconnection)
# ***************************************************************************


